Evidence from the existing Windows workspace, 13 September 2026.
The current Qwen GGUF is required; no model weights or binaries are included.
Original expert extracts can be reconstructed with cpu/extract_original_weights.py.
CPU build script references the existing local source/build paths. Run from its directory.
Run python cache/replay_cache.py to reproduce the cache comparison from the included trace.
All CPU performance results use unchanged IQ2_S/IQ4_NL weights, not a Q4 conversion.
Q4 comparison/download deferred by the user. No whole-model speedup measured here.
Sync graph uses empty callbacks; it does not measure a complete heterogeneous layer.
