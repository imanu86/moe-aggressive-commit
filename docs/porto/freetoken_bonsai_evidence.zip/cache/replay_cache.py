"""Offline policy comparison on a fixed trace; no end-to-end speed prediction."""
import collections
import argparse
import hashlib
import importlib.util
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
HERE = pathlib.Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--trace', type=pathlib.Path, default=HERE/'trace64.jsonl' if (HERE/'trace64.jsonl').exists() else ROOT/'work/cache_a/trace64.jsonl')
parser.add_argument('--baseline', type=pathlib.Path, default=HERE/'analyze_trace.py' if (HERE/'analyze_trace.py').exists() else ROOT/'outputs/analyze_trace.py')
parser.add_argument('--out', type=pathlib.Path, default=HERE/'cache_policy_results.json')
args = parser.parse_args()
TRACE = args.trace
spec = importlib.util.spec_from_file_location('baseline', args.baseline)
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)


class ByteLRU:
    def __init__(self, budget):
        self.budget = budget
        self.bytes = 0
        self.data = collections.OrderedDict()

    def access(self, keys, size):
        keys = sorted(set(keys))
        requested = set(keys)
        misses = [key for key in keys if key not in self.data]
        assert len(keys) * size <= self.budget
        # Protect every current hit before admitting any miss.
        for key in keys:
            if key in self.data:
                self.data.move_to_end(key)
        for key in misses:
            while self.bytes + size > self.budget:
                victim, oldsize = next(iter(self.data.items()))
                assert victim not in requested
                del self.data[victim]
                self.bytes -= oldsize
            self.data[key] = size
            self.bytes += size
        # Deterministic id order within one batched access; no within-batch locality claim.
        for key in keys:
            self.data.move_to_end(key)
        assert self.bytes <= self.budget and requested <= self.data.keys()
        return len(misses)

    def invalidate_group(self, group_layer):
        for key in list(self.data):
            if key[:2] == group_layer:
                self.bytes -= self.data.pop(key)


def validate_lru():
    cache = ByteLRU(8)
    assert cache.access([1, 2, 1], 3) == 2
    assert cache.access([1, 3], 3) == 1
    assert set(cache.data) == {1, 3}
    assert cache.access([4], 2) == 1
    assert cache.bytes == 8
    assert cache.access([1], 3) == 0
    assert cache.access([5], 4) == 1
    assert set(cache.data) == {1, 5} and cache.bytes == 7


def main():
    validate_lru()
    records = [json.loads(line) for line in TRACE.read_text().splitlines() if line.strip()]
    sizes, previous = {}, {}
    for rec in records:
        key = (rec['group'], rec['layer'])
        assert rec['step'] == previous.get(key, 0) + 1
        previous[key] = rec['step']
        assert sizes.setdefault(key, rec['bytes_per_miss']) == rec['bytes_per_miss']
        assert len(set(rec['ids'])) == rec['requested']
    layer_sizes = {}
    for (_, layer), size in sizes.items():
        assert layer_sizes.setdefault(layer, size) == size
    # Group identifies a cache incarnation, not extra simultaneous physical capacity.
    budget = 64 * sum(layer_sizes.values())
    pooled = ByteLRU(budget)
    lru = {key: ByteLRU(64 * size) for key, size in sizes.items()}
    lfu = {key: baseline.Cache(64) for key in sizes}
    counters = {policy: {window: collections.Counter() for window in ('all', 'step_gt_64')}
                for policy in ('measured_lfu', 'per_layer_lru', 'ideal_pooled_byte_lru')}
    mismatches = 0
    active_groups = {}
    for rec in records:
        key = (rec['group'], rec['layer'])
        old_key = active_groups.get(rec['layer'])
        if old_key is not None and old_key != key:
            pooled.invalidate_group(old_key)
        active_groups[rec['layer']] = key
        ids = list(dict.fromkeys(rec['ids']))
        size = rec['bytes_per_miss']
        _, misses = lfu[key].replay(ids, rec['step'])
        mismatches += misses != rec['misses']
        outcomes = {
            'measured_lfu': misses,
            'per_layer_lru': lru[key].access(ids, size),
            'ideal_pooled_byte_lru': pooled.access([(*key, i) for i in ids], size),
        }
        for policy, count in outcomes.items():
            for window in ('all', 'step_gt_64') if rec['step'] > 64 else ('all',):
                counters[policy][window].update(plans=1, requested=len(ids), misses=count,
                                                payload_bytes=count * size)
    assert mismatches == 0
    for windows in counters.values():
        for counts in windows.values():
            counts['hit_percent'] = 100 * (1 - counts['misses'] / counts['requested'])
    result = {
        'trace_sha256': hashlib.sha256(TRACE.read_bytes()).hexdigest(),
        'records': len(records), 'cache_incarnations': len(sizes), 'physical_layers': len(layer_sizes),
        'baseline_mismatches': mismatches, 'logical_payload_budget_bytes': budget,
        'assumptions': [
            'All policies start empty and consume the same file order and expert ids.',
            'Group changes replace the cache incarnation for that layer; old pooled entries are invalidated.',
            'Warm statistics exclude the first 64 plans of each layer; state is not reset.',
            'Baseline uses original request order and reproduces recorded misses exactly.',
            'LRU batch ties use expert-id order, with all current hits protected.',
            'Pooled LRU is ideal variable-size packing at the same sum of expert payload budgets.',
            'No allocator padding, metadata, GPU kernel costs, or CPU offload modeled.',
            'This is not a bit-exact replay of FreeToken, whose fixed-shape banks differ.',
            'This is one historical routing trace, not a new tokens/s benchmark.',
        ],
        'results': counters,
    }
    out = args.out
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
