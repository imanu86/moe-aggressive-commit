@echo off
setlocal
set ROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
if not exist bin mkdir bin
cl /nologo /std:c++17 /O2 /EHsc /MD /I"%ROOT%\source\ggml\include" quant_moe_bench.cpp /link "%ROOT%\build\ggml\src\ggml-cpu.lib" "%ROOT%\build\ggml\src\ggml-base.lib" "%ROOT%\build\ggml\src\ggml.lib" /OUT:bin\quant_moe_bench.exe
if errorlevel 1 exit /b 1
copy /y "%ROOT%\build\bin\ggml-cpu.dll" bin\ >nul
copy /y "%ROOT%\build\bin\ggml-base.dll" bin\ >nul
copy /y "%ROOT%\build\bin\ggml.dll" bin\ >nul
cl /nologo /std:c++17 /O2 /EHsc /MD /I"%ROOT%\source\ggml\include" cpu_moe_probe.cpp /link "%ROOT%\build\ggml\src\ggml-cpu.lib" "%ROOT%\build\ggml\src\ggml-base.lib" "%ROOT%\build\ggml\src\ggml.lib" /OUT:bin\cpu_moe_probe.exe
if errorlevel 1 exit /b 1
exit /b 0
