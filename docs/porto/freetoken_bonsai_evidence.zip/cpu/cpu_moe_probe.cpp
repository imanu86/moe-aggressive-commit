#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <numeric>
#include <string>
#include <vector>

static std::vector<uint8_t> load(const std::string & p, size_t n) { std::ifstream f(p, std::ios::binary|std::ios::ate); if (!f || f.tellg() != (std::streamoff)n) throw std::runtime_error("bad weight file: "+p); std::vector<uint8_t> v(n); f.seekg(0); f.read((char *)v.data(), n); return v; }
static void usage() { std::printf("--gate file --up file --down file [--selected N] [--threads N] [--iterations N]\n"); }
int main(int argc, char ** argv) try {
    std::string pg,pu,pd; int sel=1, thr=8, iters=500;
    for(int i=1;i<argc;i++){std::string a=argv[i];auto v=[&](){if(i+1>=argc)throw std::runtime_error("missing value");return std::string(argv[++i]);};
        if(a=="--gate")pg=v();else if(a=="--up")pu=v();else if(a=="--down")pd=v();else if(a=="--selected")sel=std::stoi(v());else if(a=="--threads")thr=std::stoi(v());else if(a=="--iterations")iters=std::stoi(v());else if(a=="--help"){usage();return 0;}else throw std::runtime_error("unknown option");}
    const int64_t K=2560,R=640,E=128,D=2560; if(pg.empty()||pu.empty()||pd.empty()||sel<1||sel>10||thr<1||thr>64||iters<1)throw std::runtime_error("invalid arguments");
    const size_t gb=ggml_row_size(GGML_TYPE_IQ2_S,K)*R*E;
    auto wg=load(pg,gb), wu=load(pu,gb), wd=load(pd,ggml_row_size(GGML_TYPE_IQ4_NL,R)*D*E);
    ggml_init_params ip{4ull<<20,nullptr,true}; ggml_context * c=ggml_init(ip); if(!c)throw std::runtime_error("ggml init");
    auto * gate=ggml_new_tensor_3d(c,GGML_TYPE_IQ2_S,K,R,E), * up=ggml_new_tensor_3d(c,GGML_TYPE_IQ2_S,K,R,E), * down=ggml_new_tensor_3d(c,GGML_TYPE_IQ4_NL,R,D,E);
    auto * x=ggml_new_tensor_3d(c,GGML_TYPE_F32,K,1,1), * ids=ggml_new_tensor_2d(c,GGML_TYPE_I32,sel,1);
    auto * g=ggml_mul_mat_id(c,gate,x,ids), * u=ggml_mul_mat_id(c,up,x,ids), * h=ggml_mul(c,ggml_silu(c,g),u), * y=ggml_mul_mat_id(c,down,h,ids);
    auto * gr=ggml_new_graph_custom(c,64,false); ggml_build_forward_expand(gr,y); ggml_backend_t be=ggml_backend_cpu_init(); if(!be)throw std::runtime_error("cpu backend");
    ggml_backend_cpu_set_n_threads(be,thr); auto tp=ggml_threadpool_params_default(thr); auto * pool=ggml_threadpool_new(&tp); ggml_backend_cpu_set_threadpool(be,pool);
    auto * buf=ggml_backend_alloc_ctx_tensors(c,be); if(!buf)throw std::runtime_error("alloc"); ggml_backend_tensor_set(gate,wg.data(),0,wg.size()); ggml_backend_tensor_set(up,wu.data(),0,wu.size()); ggml_backend_tensor_set(down,wd.data(),0,wd.size());
    std::vector<float> xv(K); for(int64_t i=0;i<K;i++)xv[i]=std::sin(float(i)*.013f); ggml_backend_tensor_set(x,xv.data(),0,xv.size()*sizeof(float));
    auto run=[&](int q){for(int j=0;j<sel;j++)ggml_set_i32_1d(ids,j,(q*sel+j)%E);if(ggml_backend_graph_compute(be,gr)!=GGML_STATUS_SUCCESS)throw std::runtime_error("compute");};
    for(int i=0;i<10;i++)run(i); std::vector<double> ms; ms.reserve(iters); for(int i=0;i<iters;i++){auto a=std::chrono::steady_clock::now();run(i+10);auto b=std::chrono::steady_clock::now();ms.push_back(std::chrono::duration<double,std::milli>(b-a).count());}
    std::vector<float> qg(K),qu(K),qh(R),qd(R); double ss=0,sd=0,maxe=0; for(int j=0;j<sel;j++){int e=((iters+9)*sel+j)%E; const uint8_t * ag=wg.data()+e*ggml_row_size(GGML_TYPE_IQ2_S,K)*R,* au=wu.data()+e*ggml_row_size(GGML_TYPE_IQ2_S,K)*R,* ad=wd.data()+e*ggml_row_size(GGML_TYPE_IQ4_NL,R)*D; for(int r=0;r<R;r++){ggml_get_type_traits(GGML_TYPE_IQ2_S)->to_float(ag+r*ggml_row_size(GGML_TYPE_IQ2_S,K),qg.data(),K);ggml_get_type_traits(GGML_TYPE_IQ2_S)->to_float(au+r*ggml_row_size(GGML_TYPE_IQ2_S,K),qu.data(),K);float a=0,b=0;for(int k=0;k<K;k++){a+=qg[k]*xv[k];b+=qu[k]*xv[k];}qh[r]=a/(1+std::exp(-a))*b;}
        for(int r=0;r<D;r++){ggml_get_type_traits(GGML_TYPE_IQ4_NL)->to_float(ad+r*ggml_row_size(GGML_TYPE_IQ4_NL,R),qd.data(),R);float z=0;for(int k=0;k<R;k++)z+=qd[k]*qh[k];float got=((float*)y->data)[j*D+r];if(!std::isfinite(got)||!std::isfinite(z))throw std::runtime_error("nonfinite output/reference");double d=got-z;maxe=std::max(maxe,std::abs(d));sd+=d*d;ss+=double(z)*z;}
    }
    std::sort(ms.begin(),ms.end()); double med=ms[ms.size()/2]; std::printf("selected=%d threads=%d iters=%d gate=IQ2_S up=IQ2_S down=IQ4_NL median_ms=%.4f p10_ms=%.4f p90_ms=%.4f nrmse=%.9g maxerr=%.9g checksum=%.9g payload_GBps=%.3f\n",sel,thr,iters,med,ms[ms.size()/10],ms[ms.size()*9/10],std::sqrt(ss?sd/ss:sd),maxe,std::accumulate((float*)y->data,(float*)y->data+sel*D,0.0),(sel*(2*ggml_row_size(GGML_TYPE_IQ2_S,K)*R+ggml_row_size(GGML_TYPE_IQ4_NL,R)*D))/(med*1e6));
    if(!std::isfinite(maxe)|| (ss && std::sqrt(sd/ss)>.05))throw std::runtime_error("reference mismatch"); ggml_backend_buffer_free(buf);ggml_backend_free(be);ggml_threadpool_free(pool);ggml_free(c);return 0;
} catch(const std::exception &e){std::fprintf(stderr,"error: %s\n",e.what());return 2;}
