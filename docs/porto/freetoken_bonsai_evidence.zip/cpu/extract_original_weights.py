"""Extract unchanged real expert rows using the recorded GGUF offsets and hashes."""
import argparse
import hashlib
import json
import pathlib

parser = argparse.ArgumentParser()
parser.add_argument('--manifest', type=pathlib.Path, default=pathlib.Path(__file__).with_name('original_weight_manifest.json'))
parser.add_argument('--source', type=pathlib.Path)
parser.add_argument('--out', type=pathlib.Path, default=pathlib.Path(__file__).parent)
args = parser.parse_args()
manifest = json.loads(args.manifest.read_text())
source = args.source or pathlib.Path(manifest['source'])
if source.stat().st_size != manifest['source_size']:
    raise ValueError('GGUF size differs from recorded source')
args.out.mkdir(parents=True, exist_ok=True)
with source.open('rb') as src:
    for tensor in manifest['tensors']:
        src.seek(tensor['data_offset'])
        data = src.read(tensor['extract_bytes'])
        if hashlib.sha256(data).hexdigest() != tensor['sha256']:
            raise ValueError('Tensor byte identity failed: ' + tensor['name'])
        dst = args.out / tensor['file']
        dst.write_bytes(data)
        print(tensor['name'], len(data), 'verified')
