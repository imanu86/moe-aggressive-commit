#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

struct opts { enum ggml_type type = GGML_TYPE_IQ2_S; int64_t K=2560, R=640, E=128, sel=4, threads=8, iterations=100; std::string weights; };

static enum ggml_type parse_type(const std::string & s) {
    if (s == "iq2_s") return GGML_TYPE_IQ2_S;
    if (s == "iq3_xxs") return GGML_TYPE_IQ3_XXS;
    if (s == "q3_k") return GGML_TYPE_Q3_K;
    if (s == "q4_k") return GGML_TYPE_Q4_K;
    if (s == "q4_0" || s == "q4_02") return GGML_TYPE_Q4_0;
    if (s == "iq4_nl") return GGML_TYPE_IQ4_NL;
    throw std::runtime_error("unknown --type");
}
static void usage() { std::printf("--type iq2_s|iq3_xxs|q3_k|q4_k|q4_0|q4_02|iq4_nl --K N --R N --experts N --selected N --threads N --iterations N --weights packed\n"); }
static opts args(int argc, char ** argv) {
    opts o;
    for (int i=1;i<argc;i++) {
        std::string a=argv[i];
        auto val=[&](const char * n)->std::string { if (i+1>=argc) throw std::runtime_error(std::string("missing ")+n); return argv[++i]; };
        if(a=="--type") o.type=parse_type(val("--type")); else if(a=="--K") o.K=std::stoll(val("--K"));
        else if(a=="--R") o.R=std::stoll(val("--R")); else if(a=="--experts") o.E=std::stoll(val("--experts"));
        else if(a=="--selected") o.sel=std::stoll(val("--selected")); else if(a=="--threads") o.threads=std::stoi(val("--threads")); else if(a=="--iterations") o.iterations=std::stoi(val("--iterations"));
        else if(a=="--weights") o.weights=val("--weights"); else if(a=="--help"){usage();std::exit(0);} else throw std::runtime_error("unknown option "+a);
    }
    if(o.K<=0||o.R<=0||o.E<=0||o.sel<=0||o.sel>o.E||o.threads<1||o.threads>64||o.iterations<1||o.K%ggml_blck_size(o.type)!=0||o.weights.empty()) throw std::runtime_error("invalid dimensions or required --weights missing");
    return o;
}
static double median(std::vector<double> x) { std::sort(x.begin(),x.end()); return x[x.size()/2]; }

int main(int argc, char ** argv) try {
    opts o=args(argc,argv); ggml_init_params ip{0};
    const size_t row_bytes=ggml_row_size(o.type,o.K), expert_bytes=row_bytes*o.R;
    const size_t weight_bytes=expert_bytes*o.E;
    ip.mem_size = 4ull << 20; ip.no_alloc = true;
    ggml_context * ctx=ggml_init(ip); if(!ctx) throw std::runtime_error("ggml_init failed");
    ggml_tensor * as=ggml_new_tensor_3d(ctx,o.type,o.K,o.R,o.E);
    ggml_tensor * b=ggml_new_tensor_3d(ctx,GGML_TYPE_F32,o.K,1,1);
    ggml_tensor * ids=ggml_new_tensor_2d(ctx,GGML_TYPE_I32,o.sel,1);
    ggml_tensor * out=ggml_mul_mat_id(ctx,as,b,ids);
    ggml_cgraph * graph=ggml_new_graph_custom(ctx,32,false); ggml_build_forward_expand(graph,out);
    ggml_backend_t backend=ggml_backend_cpu_init(); if(!backend) throw std::runtime_error("cpu backend failed");
    ggml_backend_cpu_set_n_threads(backend, o.threads);
    ggml_threadpool_params tp_params = ggml_threadpool_params_default(o.threads);
    ggml_threadpool_t threadpool = ggml_threadpool_new(&tp_params);
    if (!threadpool) throw std::runtime_error("threadpool failed");
    ggml_backend_cpu_set_threadpool(backend,threadpool);
    ggml_backend_buffer_t buf=ggml_backend_alloc_ctx_tensors(ctx,backend); if(!buf) throw std::runtime_error("allocation failed");
    std::vector<uint8_t> packed(weight_bytes); { std::ifstream f(o.weights,std::ios::binary|std::ios::ate); if(!f) throw std::runtime_error("cannot open weights"); const auto n=f.tellg(); if(n!=(std::streamoff)weight_bytes) throw std::runtime_error("weights file size does not match shape/type"); f.seekg(0); f.read((char*)packed.data(),packed.size()); }
    ggml_backend_tensor_set(as,packed.data(),0,packed.size());
    std::vector<float> act(o.K); for(int64_t i=0;i<o.K;i++) act[i]=std::sin(float(i)*0.013f);
    ggml_backend_tensor_set(b,act.data(),0,act.size()*sizeof(float));
    std::vector<float> deq(o.K), ref(o.sel*o.R); std::vector<double> times; times.reserve(o.iterations);
    auto run=[&](int it){ for(int64_t j=0;j<o.sel;j++) ((int32_t*)ids->data)[j]=(it*o.sel+j)%o.E; ggml_status st=ggml_backend_graph_compute(backend,graph); if(st!=GGML_STATUS_SUCCESS) throw std::runtime_error("compute failed"); };
    for(int i=0;i<10;i++) run(i);
    double maxerr=0, norm=0, checksum=0;
    for(int it=0;it<o.iterations;it++){ auto t0=std::chrono::steady_clock::now(); run(it+10); auto t1=std::chrono::steady_clock::now(); double ms=std::chrono::duration<double,std::milli>(t1-t0).count(); times.push_back(ms); checksum=0; for(int64_t j=0;j<o.sel*o.R;j++) checksum+=((float*)out->data)[j]; }
    for(int64_t j=0;j<o.sel;j++){ int e=((o.iterations+9)*o.sel+j)%o.E; const uint8_t * row=packed.data()+e*expert_bytes; for(int64_t r=0;r<o.R;r++){ ggml_get_type_traits(o.type)->to_float(row+r*row_bytes,deq.data(),o.K); double dot=0; for(int64_t k=0;k<o.K;k++) dot+=deq[k]*act[k]; ref[j*o.R+r]=(float)dot; } }
    double sumdiff=0, sumref=0; for(size_t i=0;i<ref.size();i++){ double got=((float*)out->data)[i]; if(!std::isfinite(got)) throw std::runtime_error("non-finite output"); double d=got-ref[i]; maxerr=std::max(maxerr,std::abs(d)); sumdiff+=d*d; sumref+=double(ref[i])*ref[i]; }
    const double nrmse=std::sqrt(sumref>0?sumdiff/sumref:sumdiff); if(nrmse>0.05) throw std::runtime_error("reference NRMSE > 0.05");
    const double med=median(times), mean=std::accumulate(times.begin(),times.end(),0.0)/times.size(); std::sort(times.begin(),times.end());
    std::printf("type=%s K=%lld R=%lld experts=%lld selected=%lld threads=%lld avx2=%d vnni=%d iterations=%lld bytes=%zu median_ms=%.4f mean_ms=%.4f p10_ms=%.4f p90_ms=%.4f payload_GBps=%.3f checksum=%.9g maxerr=%.9g nrmse=%.9g\n",ggml_type_name(o.type),(long long)o.K,(long long)o.R,(long long)o.E,(long long)o.sel,(long long)o.threads,ggml_cpu_has_avx2(),ggml_cpu_has_avx_vnni(),(long long)o.iterations,weight_bytes,med,mean,times[times.size()/10],times[times.size()*9/10],(double)(o.sel*expert_bytes)/(med*1e6),checksum,maxerr,nrmse);
    ggml_backend_buffer_free(buf); ggml_backend_free(backend); ggml_threadpool_free(threadpool); ggml_free(ctx); return 0;
} catch(const std::exception & e){ std::fprintf(stderr,"error: %s\n",e.what()); return 2; }
