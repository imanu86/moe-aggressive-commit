@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
where cl.exe
where nvcc.exe
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin\nvcc.exe" --use-local-env -O2 -std=c++17 -arch=sm_86 -Xcompiler "/EHsc,/MD" -L"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\lib\x64" -lcuda -o "%~dp0sync_probe.exe" "%~dp0sync_probe.cu"
exit /b %errorlevel%
