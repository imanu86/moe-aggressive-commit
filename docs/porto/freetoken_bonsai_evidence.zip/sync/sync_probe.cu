#include <cuda.h>
#include <cuda_runtime_api.h>

#include <windows.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

using CuMemOp64 = CUresult (CUDAAPI *)(CUstream, CUdeviceptr, cuuint64_t, unsigned int);

static const char* cu_name(CUresult rc) {
  const char* name = nullptr;
  cuGetErrorName(rc, &name);
  return name ? name : "<unknown>";
}

static const char* cuda_name(cudaError_t rc) {
  return cudaGetErrorName(rc);
}

static bool check_cuda(cudaError_t rc, const char* what) {
  if (rc != cudaSuccess) {
    std::fprintf(stderr, "CUDA_FAIL %s code=%d name=%s text=%s\n", what,
                 static_cast<int>(rc), cuda_name(rc), cudaGetErrorString(rc));
    return false;
  }
  return true;
}

static LARGE_INTEGER now_ticks() {
  LARGE_INTEGER t;
  QueryPerformanceCounter(&t);
  return t;
}

static double ms_between(LARGE_INTEGER a, LARGE_INTEGER b, LARGE_INTEGER freq) {
  return 1000.0 * static_cast<double>(b.QuadPart - a.QuadPart) /
         static_cast<double>(freq.QuadPart);
}

static void CUDART_CB noop_host(void*) {}

static bool graph_bench(cudaStream_t stream, int host_nodes, int launches,
                        std::vector<double>* samples) {
  cudaGraph_t graph = nullptr;
  cudaGraphExec_t exec = nullptr;
  if (!check_cuda(cudaGraphCreate(&graph, 0), "cudaGraphCreate")) return false;

  cudaGraphNode_t previous = nullptr;
  for (int i = 0; i < host_nodes; ++i) {
    cudaGraphNode_t node = nullptr;
    cudaHostNodeParams params{};
    params.fn = noop_host;
    params.userData = nullptr;
    const cudaGraphNode_t* deps = previous ? &previous : nullptr;
    const size_t ndeps = previous ? 1 : 0;
    if (!check_cuda(cudaGraphAddHostNode(&node, graph, deps, ndeps, &params),
                    "cudaGraphAddHostNode")) {
      cudaGraphDestroy(graph);
      return false;
    }
    previous = node;
  }
  if (!check_cuda(cudaGraphInstantiate(&exec, graph, nullptr, nullptr, 0),
                  "cudaGraphInstantiate")) {
    cudaGraphDestroy(graph);
    return false;
  }

  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  samples->clear();
  samples->reserve(launches);
  for (int i = 0; i < launches; ++i) {
    LARGE_INTEGER start = now_ticks();
    if (!check_cuda(cudaGraphLaunch(exec, stream), "cudaGraphLaunch")) {
      cudaGraphExecDestroy(exec);
      cudaGraphDestroy(graph);
      return false;
    }
    if (!check_cuda(cudaStreamSynchronize(stream), "cudaStreamSynchronize(graph)")) {
      cudaGraphExecDestroy(exec);
      cudaGraphDestroy(graph);
      return false;
    }
    samples->push_back(ms_between(start, now_ticks(), freq));
  }
  if (!check_cuda(cudaGraphExecDestroy(exec), "cudaGraphExecDestroy")) {
    cudaGraphDestroy(graph);
    return false;
  }
  return check_cuda(cudaGraphDestroy(graph), "cudaGraphDestroy");
}

static double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  const size_t n = values.size();
  return n & 1 ? values[n / 2] : 0.5 * (values[n / 2 - 1] + values[n / 2]);
}

int main() {
  constexpr int kLaunches = 30;
  constexpr int kHostNodes = 96;  // two callback nodes x 48 layers

  if (!check_cuda(cudaSetDevice(0), "cudaSetDevice(0)")) return 2;

  HMODULE driver = LoadLibraryA("nvcuda.dll");
  if (!driver) {
    std::fprintf(stderr, "MEMOPS_UNSUPPORTED nvcuda.dll load failed win32=%lu\n",
                 GetLastError());
    return 3;
  }
  auto write64 = reinterpret_cast<CuMemOp64>(
      GetProcAddress(driver, "cuStreamWriteValue64_v2"));
  auto wait64 = reinterpret_cast<CuMemOp64>(
      GetProcAddress(driver, "cuStreamWaitValue64_v2"));
  if (!write64) write64 = reinterpret_cast<CuMemOp64>(
      GetProcAddress(driver, "cuStreamWriteValue64"));
  if (!wait64) wait64 = reinterpret_cast<CuMemOp64>(
      GetProcAddress(driver, "cuStreamWaitValue64"));
  if (!write64 || !wait64) {
    std::fprintf(stderr, "MEMOPS_UNSUPPORTED write64=%s wait64=%s\n",
                 write64 ? "present" : "missing", wait64 ? "present" : "missing");
    FreeLibrary(driver);
    return 4;
  }

  uint64_t* flag = nullptr;
  if (!check_cuda(cudaHostAlloc(reinterpret_cast<void**>(&flag), sizeof(*flag),
                                cudaHostAllocMapped | cudaHostAllocPortable),
                  "cudaHostAlloc(mapped flag)")) {
    FreeLibrary(driver);
    return 5;
  }
  *flag = 0;
  cudaStream_t stream = nullptr;
  if (!check_cuda(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking),
                  "cudaStreamCreateWithFlags")) {
    cudaFreeHost(flag);
    FreeLibrary(driver);
    return 6;
  }

  CUstream cu_stream = reinterpret_cast<CUstream>(stream);
  CUdeviceptr addr = reinterpret_cast<CUdeviceptr>(flag);  // same host pointer FreeToken passes
  CUresult wr = write64(cu_stream, addr, 1, 0);
  std::printf("MEMOP_WRITE code=%d name=%s addr_mode=host_data_ptr\n",
              static_cast<int>(wr), cu_name(wr));
  bool memops_ok = false;
  if (wr == CUDA_SUCCESS) {
    CUresult wa = wait64(cu_stream, addr, 1, CU_STREAM_WAIT_VALUE_GEQ);
    std::printf("MEMOP_WAIT code=%d name=%s comparator=GEQ\n",
                static_cast<int>(wa), cu_name(wa));
    if (wa == CUDA_SUCCESS) {
      cudaError_t sync_rc = cudaStreamSynchronize(stream);
      std::printf("MEMOP_SYNC code=%d name=%s flag=%llu\n", static_cast<int>(sync_rc),
                  cuda_name(sync_rc), static_cast<unsigned long long>(*flag));
      memops_ok = sync_rc == cudaSuccess && *flag >= 1;
    } else {
      std::printf("MEMOPS_UNSUPPORTED wait failure; no blocking wait was issued\n");
    }
  } else {
    std::printf("MEMOPS_UNSUPPORTED write failure; wait was intentionally not issued\n");
  }
  std::printf("MEMOPS_RESULT %s\n", memops_ok ? "supported" : "unsupported");

  std::vector<double> empty_samples, host_samples;
  bool bench_ok = graph_bench(stream, 0, kLaunches, &empty_samples) &&
                  graph_bench(stream, kHostNodes, kLaunches, &host_samples);
  if (bench_ok) {
    const double empty_med = median(empty_samples);
    const double host_med = median(host_samples);
    std::printf("GRAPH_RESULT launches=%d host_nodes=%d empty_median_ms=%.6f "
                "host_median_ms=%.6f delta_ms=%.6f per_host_node_us=%.3f\n",
                kLaunches, kHostNodes, empty_med, host_med, host_med - empty_med,
                (host_med - empty_med) * 1000.0 / kHostNodes);
  }

  bool cleanup_ok = check_cuda(cudaStreamDestroy(stream), "cudaStreamDestroy") &&
                    check_cuda(cudaFreeHost(flag), "cudaFreeHost(flag)");
  FreeLibrary(driver);
  if (!bench_ok || !cleanup_ok) return 7;
  return memops_ok ? 0 : 8;
}
