# Prototipo FreeToken: CPU fusa e sovrapposizione CUDA

Esperimento locale del 13 settembre 2026. Non è integrato nel server.
Usa pesi originali GGUF IQ2_S gate/up e IQ4_NL down, 128 esperti del layer 0.
La CPU serve uno o pochi miss mentre la GPU carica e calcola gli altri esperti.

Prerequisiti: la build privata GGML indicata nei file `.cmd`, Visual Studio 2022,
CUDA Toolkit 12.6, driver NVIDIA 596.21, Python. Le librerie GGML devono corrispondere
agli header della build: il prototipo legge la struttura interna del backend per
ottenere il suo stream. Il manifest registra gli hash dei file rilevanti.
I pesi e le DLL non sono inclusi nell'archivio.

1. Estrarre i pesi invariati con `weights/extract_original_weights.py`, scegliendo
   `--out` e, se necessario, `--source`. Lo script verifica SHA256 di ogni banca.
2. In `prototype`, eseguire `build.cmd` e `build_overlap.cmd`.
3. Aggiungere `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin` al PATH.
4. `cpu_test.exe 2 4 PERCORSO_PESI` verifica il riferimento GGML CPU e la somma.
5. `overlap_probe.exe 3 2 4 2 0 16 PERCORSO_PESI` confronta baseline e ibrido.

Argomenti di overlap_probe: miss totali, esperti CPU, thread CPU fisici,
comunicazione, ordine inverso (0/1), replay prima della sincronizzazione,
directory dei pesi. In tutte le modalità il risultato finale è in VRAM.

| Comunicazione | Percorso |
|---|---|
| 0 | D2H/H2D espliciti, flag CUDA driver |
| 1 | RAM pinnata mappata, flag CUDA driver |
| 2 | RAM pinnata mappata, callback submit/wait, CPU e GPU concorrenti |
| 3 | D2H/H2D espliciti, callback submit/wait |
| 4 | Come 2, ma CPU completata prima del lavoro GPU: controllo seriale |

`confirm_overlap.py` esegue 45 prove sequenziali, con ordine alternato e tre
processi per configurazione; i percorsi predefiniti riflettono il workspace
originale (`../cpu_quant_audit`). `run_overlap.py` ripete la griglia esplorativa
delle modalità 1 e 2. Ogni processo viene terminato dopo 45 secondi dal runner
se non conclude. La callback di attesa ha anche un limite di 10 secondi.
Le attese CUDA a flag richiedono il watchdog esterno: non usare il prototipo
come componente server senza un protocollo di annullamento/errori completo.

`fused_cpu.hpp` richiede un unico proprietario seriale che crea, usa e distrugge
il pool sullo stesso thread. Non supporta chiamanti concorrenti. Il coordinatore
del benchmark rispetta questo vincolo. I worker occupano core fisici distinti
e attendono attivamente: consumano CPU anche fra i job.

Il graph esterno cattura prepare, trasferimenti, calcolo GGML, handshake e merge.
La cattura automatica interna GGML è disattivata solo nel processo sonda per
evitare una cattura annidata. `batch_size=16` non è un batch di token: sono 16
invocazioni seriali dello stesso blocco, con una sincronizzazione host alla fine.
Le prove con `batch_size=1` verificano anche la latenza di un'invocazione.

Limiti: un token, 10 esperti attivi, K=2560/H=640, un solo layer e attivazioni
sintetiche. I miss sono imposti; manca l'interazione con ammissione/evizione LFU.
Il prototipo non implementa MTP, router reale, shared expert, attenzione, dense
residenti o prefill. CPU e GPU quantizzano diversamente le attivazioni e non sono
bit-identiche. Le prove non dimostrano qualità o velocità del modello completo.

`inspect_expert_types.py` legge la directory tensori dei GGUF locali, senza
leggere payload. I codici quant vanno interpretati con `ggml.h`: 21=IQ3_S,
22=IQ2_S, 20=IQ4_NL. Lo strato 2 richiede un'estensione o fallback GPU.
