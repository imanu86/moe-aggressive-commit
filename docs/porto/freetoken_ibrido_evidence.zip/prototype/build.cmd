@echo off
setlocal
cd /d "%~dp0"
set "QROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /O2 /EHsc /MD /I"%QROOT%\source\ggml\include" cpu_test.cpp /link "%QROOT%\build\ggml\src\ggml-cpu.lib" "%QROOT%\build\ggml\src\ggml-base.lib" "%QROOT%\build\ggml\src\ggml.lib" /OUT:cpu_test.exe
if errorlevel 1 exit /b 1
copy /y "%QROOT%\build\bin\ggml-cpu.dll" . >nul
copy /y "%QROOT%\build\bin\ggml-base.dll" . >nul
copy /y "%QROOT%\build\bin\ggml.dll" . >nul
