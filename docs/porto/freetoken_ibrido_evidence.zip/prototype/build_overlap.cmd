@echo off
setlocal
cd /d "%~dp0"
set "QROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
nvcc --use-local-env -O2 -std=c++17 -arch=sm_86 -Xcompiler "/EHsc,/MD" -I"%QROOT%\source\ggml\include" -I"%QROOT%\source\ggml\src" -I"%QROOT%\source\ggml\src\ggml-cuda" overlap_probe.cu -o overlap_probe.exe "%QROOT%\build\ggml\src\ggml-cpu.lib" "%QROOT%\build\ggml\src\ggml-base.lib" "%QROOT%\build\ggml\src\ggml.lib" "%QROOT%\build\ggml\src\ggml-cuda\ggml-cuda.lib" -lcuda
if errorlevel 1 exit /b 1
copy /y "%QROOT%\build\bin\ggml-cuda.dll" . >nul
copy /y "%QROOT%\build\bin\ggml-cpu.dll" . >nul
copy /y "%QROOT%\build\bin\ggml-base.dll" . >nul
copy /y "%QROOT%\build\bin\ggml.dll" . >nul
