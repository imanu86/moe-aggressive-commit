"""Sequential confirmation, alternating baseline/candidate process order."""
import json, os, pathlib, re, subprocess
root=pathlib.Path(__file__).resolve().parent
env=os.environ.copy()
env['PATH']=r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin;'+env['PATH']
# m, CPU experts, CPU physical cores, communication mode, layer launches/batch
configs=[(1,1,6,2,16),(2,2,6,2,16),(3,2,6,2,16),(3,3,6,2,16),(4,3,6,2,16),
         (3,2,4,2,16),(3,2,8,2,16),(4,4,6,2,16),
         (3,2,6,0,16),(3,2,6,1,16),(3,2,6,3,16),(3,2,6,4,16),
         (2,2,6,2,1),(3,2,6,2,1),(4,3,6,2,1)]
rows=[]
for repeat in range(3):
    for idx,(m,c,t,comm,batch) in enumerate(configs):
        reverse=(repeat+idx)%2
        args=[str(root/'overlap_probe.exe'),str(m),str(c),str(t),str(comm),str(reverse),str(batch)]
        p=subprocess.run(args,cwd=root,env=env,text=True,capture_output=True,timeout=45)
        line=next((s for s in p.stdout.splitlines() if s.startswith('missing=')),None)
        if p.returncode or not line:
            print(p.stdout,p.stderr,flush=True)
            raise RuntimeError(f'probe failed {args}: {p.returncode}')
        row={k:float(v) if any(ch in v.lower() for ch in '.e') else int(v) for k,v in re.findall(r'(\w+)=([0-9.e+-]+)',line)}
        row['repeat']=repeat;rows.append(row)
        (root/'confirmation.json').write_text(json.dumps(rows,indent=2)+'\n')
        with (root/'confirmation.log').open('a') as f:f.write(p.stdout+p.stderr+'\n')
        print(f'repeat={repeat} '+line,flush=True)
