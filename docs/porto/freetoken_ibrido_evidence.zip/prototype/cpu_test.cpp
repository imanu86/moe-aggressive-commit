#include "fused_cpu.hpp"
#include "ggml-backend.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <fstream>
#include <numeric>
#include <string>
using namespace hybrid_probe;
using Clock=std::chrono::steady_clock;
static std::vector<uint8_t> load(const std::string & p,size_t n) {
    std::ifstream f(p,std::ios::binary|std::ios::ate);
    if(!f || f.tellg()!=(std::streamoff)n)throw std::runtime_error("wrong weight size: "+p);
    std::vector<uint8_t> v(n);f.seekg(0);f.read((char*)v.data(),n);return v;
}
static double median(std::vector<double> x){std::sort(x.begin(),x.end());return x[x.size()/2];}
struct Input {float x[K];int ids[EMAX];float weights[EMAX];};
int main(int argc,char **argv)try{
    int n=argc>1?std::stoi(argv[1]):2,threads=argc>2?std::stoi(argv[2]):8;
    std::string dir=argc>3?argv[3]:"../cpu_quant_audit";
    if(n<1||n>10||threads<1||threads>32)throw std::runtime_error("invalid arguments");
    constexpr int E=128, NC=128, NI=1000;
    auto gate=load(dir+"/gate_22.bin",ggml_row_size(GGML_TYPE_IQ2_S,K)*H*E);
    auto up=load(dir+"/up_22.bin",gate.size());
    auto down=load(dir+"/down_20.bin",ggml_row_size(GGML_TYPE_IQ4_NL,H)*K*E);
    std::vector<Input> inputs(NC);
    for(int c=0;c<NC;++c){
        for(int k=0;k<K;++k)inputs[c].x[k]=(c%3==0?.25f:c%3==1?1.f:4.f)*std::sin(k*.013f+c*.713f);
        for(int e=0;e<n;++e){inputs[c].ids[e]=(c*7+e*11)%E;inputs[c].weights[e]=(e+1.f)/(n*(n+1.f)/2);}
    }
    std::vector<float> ref((size_t)NC*n*K),out(K),individual(n*K);
    std::vector<double> reference_ms,fused_ms;
    {
        auto *ctx=ggml_init({4ull<<20,nullptr,true});
        auto *g=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ2_S,K,H,E);
        auto *u=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ2_S,K,H,E);
        auto *d=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ4_NL,H,K,E);
        auto *x=ggml_new_tensor_3d(ctx,GGML_TYPE_F32,K,1,1);
        auto *ids=ggml_new_tensor_2d(ctx,GGML_TYPE_I32,n,1);
        auto *hidden=ggml_mul(ctx,ggml_silu(ctx,ggml_mul_mat_id(ctx,g,x,ids)),ggml_mul_mat_id(ctx,u,x,ids));
        auto *y=ggml_mul_mat_id(ctx,d,hidden,ids);
        auto *graph=ggml_new_graph_custom(ctx,64,false);ggml_build_forward_expand(graph,y);
        auto be=ggml_backend_cpu_init();ggml_backend_cpu_set_n_threads(be,threads);
        auto params=ggml_threadpool_params_default(threads);
        auto masks=physical_first_masks();
        if(threads>(int)masks.size())throw std::runtime_error("not enough allowed CPU processors");
        for(int i=0;i<threads;++i)for(int bit=0;bit<64;++bit)if(masks[i]&(DWORD_PTR(1)<<bit))params.cpumask[bit]=true;
        params.strict_cpu=true;
        auto pool=ggml_threadpool_new(&params);
        ggml_backend_cpu_set_threadpool(be,pool);auto buf=ggml_backend_alloc_ctx_tensors(ctx,be);
        if(!buf)throw std::runtime_error("allocation failed");
        ggml_backend_tensor_set(g,gate.data(),0,gate.size());ggml_backend_tensor_set(u,up.data(),0,up.size());ggml_backend_tensor_set(d,down.data(),0,down.size());
        auto run=[&](int c){
            ggml_backend_tensor_set(x,inputs[c].x,0,K*sizeof(float));
            ggml_backend_tensor_set(ids,inputs[c].ids,0,n*sizeof(int));
            if(ggml_backend_graph_compute(be,graph)!=GGML_STATUS_SUCCESS)throw std::runtime_error("reference compute failed");
        };
        for(int c=0;c<NC;++c){run(c);ggml_backend_tensor_get(y,ref.data()+(size_t)c*n*K,0,n*K*sizeof(float));}
        for(int i=0;i<NI;++i){auto t=Clock::now();run(i%NC);reference_ms.push_back(std::chrono::duration<double,std::micro>(Clock::now()-t).count());}
        ggml_backend_buffer_free(buf);ggml_backend_free(be);ggml_threadpool_free(pool);ggml_free(ctx);
    }
    double err2=0,ref2=0,maxerr=0,merged_err2=0,merged_ref2=0;
    size_t mismatches=0;
    {
        FusedCpu cpu({gate.data(),up.data(),down.data(),E},threads);
        for(int c=0;c<NC;++c){
            cpu.run(inputs[c].x,inputs[c].ids,inputs[c].weights,n,out.data(),individual.data());
            for(int e=0;e<n;++e)for(int k=0;k<K;++k){
                double expected=ref[((size_t)c*n+e)*K+k], actual=individual[e*K+k], delta=actual-expected;
                if(!std::isfinite(actual))throw std::runtime_error("nonfinite fused output");
                mismatches+=actual!=expected;err2+=delta*delta;ref2+=expected*expected;maxerr=std::max(maxerr,std::abs(delta));
            }
            for(int k=0;k<K;++k){
                float sum=0;for(int e=0;e<n;++e)sum+=inputs[c].weights[e]*ref[((size_t)c*n+e)*K+k];
                double delta=out[k]-sum;merged_err2+=delta*delta;merged_ref2+=(double)sum*sum;
            }
        }
        for(int i=0;i<NI;++i){int c=i%NC;auto t=Clock::now();cpu.run(inputs[c].x,inputs[c].ids,inputs[c].weights,n,out.data());fused_ms.push_back(std::chrono::duration<double,std::micro>(Clock::now()-t).count());}
        cpu.run(inputs[0].x,nullptr,nullptr,0,out.data());for(float v:out)if(v!=0)throw std::runtime_error("empty CPU set failed");
    }
    double nrmse=std::sqrt(err2/std::max(ref2,1e-30));
    double merged=std::sqrt(merged_err2/std::max(merged_ref2,1e-30));
    std::printf("selected=%d threads=%d cases=%d iterations=%d reference_us=%.3f fused_us=%.3f speedup=%.3f nrmse=%.9g merged_nrmse=%.9g maxerr=%.9g unequal=%zu\n",n,threads,NC,NI,median(reference_ms),median(fused_ms),median(reference_ms)/median(fused_ms),nrmse,merged,maxerr,mismatches);
    return nrmse>1e-4||merged>1e-4?3:0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 2;}
