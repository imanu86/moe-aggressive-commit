#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "ggml.h"
#include "ggml-cpu.h"
#include <atomic>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <thread>
#include <vector>
#include <immintrin.h>
#include <windows.h>

namespace hybrid_probe {
constexpr int K = 2560, H = 640, EMAX = 10;
inline std::vector<DWORD_PTR> physical_first_masks() {
    DWORD bytes=0; GetLogicalProcessorInformation(nullptr,&bytes);
    std::vector<SYSTEM_LOGICAL_PROCESSOR_INFORMATION> info(bytes/sizeof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION));
    if(!GetLogicalProcessorInformation(info.data(),&bytes))throw std::runtime_error("CPU topology unavailable");
    DWORD_PTR allowed,system;GetProcessAffinityMask(GetCurrentProcess(),&allowed,&system);
    std::vector<DWORD_PTR> first,other;
    for(const auto &i:info)if(i.Relationship==RelationProcessorCore){
        DWORD_PTR mask=i.ProcessorMask&allowed;
        if(!mask)continue;
        DWORD_PTR bit=mask&(~mask+1);first.push_back(bit);mask^=bit;
        while(mask){bit=mask&(~mask+1);other.push_back(bit);mask^=bit;}
    }
    first.insert(first.end(),other.begin(),other.end());return first;
}
struct Banks {
    const uint8_t * gate;
    const uint8_t * up;
    const uint8_t * down;
    int experts;
    size_t gate_row = ggml_row_size(GGML_TYPE_IQ2_S, K);
    size_t down_row = ggml_row_size(GGML_TYPE_IQ4_NL, H);
    size_t gate_stride() const { return gate_row * H; }
    size_t down_stride() const { return down_row * K; }
};

class Barrier {
    const unsigned count;
    std::atomic<unsigned> arrived{0}, phase{0};
public:
    explicit Barrier(unsigned n) : count(n) {}
    void wait() {
        unsigned p = phase.load(std::memory_order_relaxed);
        if (arrived.fetch_add(1, std::memory_order_acq_rel) == count - 1) {
            arrived.store(0, std::memory_order_relaxed);
            phase.fetch_add(1, std::memory_order_release);
        } else {
            while (phase.load(std::memory_order_acquire) == p) _mm_pause();
        }
    }
};

// Fixed-shape prototype: one token, IQ2_S gate/up, IQ4_NL down, at most ten experts.
// One serialized owner must create, run, and destroy the pool on the same thread.
class FusedCpu {
    Banks banks;
    const int nth;
    Barrier barrier;
    std::vector<std::thread> workers;
    alignas(64) std::atomic<uint64_t> generation{0};
    alignas(64) std::atomic<bool> stopping{false};
    const ggml_type_traits_cpu * gate_traits;
    const ggml_type_traits_cpu * down_traits;
    ggml_from_float_t quant_x, quant_h;
    std::vector<uint8_t> xq, hq;
    size_t hq_stride, hq_block;
    int ids[EMAX]{};
    float weights[EMAX]{};
    int selected = 0;
    float * output = nullptr;
    float * individual = nullptr;
    std::vector<DWORD_PTR> masks;
    DWORD_PTR old_main_mask=0;

    void compute(int worker) {
        // Each 32-row tile owns its activation quantization block.
        for (int tile = worker; tile < selected * (H / 32); tile += nth) {
            int e = tile / (H / 32), r0 = (tile % (H / 32)) * 32;
            const auto * g = banks.gate + ids[e] * banks.gate_stride();
            const auto * u = banks.up + ids[e] * banks.gate_stride();
            alignas(64) float hidden[32];
            for (int r = 0; r < 32; ++r) {
                float gv, uv;
                gate_traits->vec_dot(K, &gv, 0, g + (r0+r)*banks.gate_row, 0, xq.data(), 0, 1);
                gate_traits->vec_dot(K, &uv, 0, u + (r0+r)*banks.gate_row, 0, xq.data(), 0, 1);
                hidden[r] = (gv / (1.0f + std::exp(-gv))) * uv;
            }
            quant_h(hidden, hq.data() + e*hq_stride + (r0/32)*hq_block, 32);
        }
        barrier.wait();
        // One worker owns an output row and sums its CPU contributions without atomics.
        for (int tile = worker; tile < K / 16; tile += nth) {
            for (int r = tile*16; r < (tile+1)*16; ++r) {
                float sum = 0;
                for (int e = 0; e < selected; ++e) {
                    float value;
                    down_traits->vec_dot(H, &value, 0,
                        banks.down + ids[e]*banks.down_stride() + r*banks.down_row, 0,
                        hq.data() + e*hq_stride, 0, 1);
                    if (individual) individual[e*K+r] = value;
                    sum += weights[e] * value;
                }
                output[r] = sum;
            }
        }
        barrier.wait();
    }
    void worker_loop(int worker) {
        SetThreadAffinityMask(GetCurrentThread(),masks[worker]);
        uint64_t observed = 0;
        while (true) {
            uint64_t next;
            unsigned spin = 0;
            while ((next = generation.load(std::memory_order_acquire)) == observed) {
                if (++spin < 20000) _mm_pause();
                else { std::this_thread::yield(); spin = 0; }
            }
            if (stopping.load(std::memory_order_relaxed)) return;
            observed = next;
            compute(worker);
        }
    }
public:
    FusedCpu(Banks b, int threads) : banks(b), nth(threads), barrier(threads) {
        if (threads < 1 || threads > 32 || b.experts < 1) throw std::runtime_error("invalid CPU pool");
        masks=physical_first_masks();
        if(threads>(int)masks.size())throw std::runtime_error("too many workers for allowed processors");
        old_main_mask=SetThreadAffinityMask(GetCurrentThread(),masks[0]);
        ggml_cpu_init();
        gate_traits = ggml_get_type_traits_cpu(GGML_TYPE_IQ2_S);
        down_traits = ggml_get_type_traits_cpu(GGML_TYPE_IQ4_NL);
        quant_x = ggml_get_type_traits_cpu(gate_traits->vec_dot_type)->from_float;
        quant_h = ggml_get_type_traits_cpu(down_traits->vec_dot_type)->from_float;
        if (!quant_x || !quant_h || ggml_blck_size(down_traits->vec_dot_type) != 32)
            throw std::runtime_error("unsupported activation layout");
        xq.resize(ggml_row_size(gate_traits->vec_dot_type, K));
        hq_stride = ggml_row_size(down_traits->vec_dot_type, H);
        hq_block = ggml_row_size(down_traits->vec_dot_type, 32);
        hq.resize(EMAX*hq_stride);
        for (int i = 1; i < nth; ++i) workers.emplace_back([this,i] { worker_loop(i); });
    }
    ~FusedCpu() {
        stopping.store(true, std::memory_order_relaxed);
        generation.fetch_add(1, std::memory_order_release);
        for (auto & w : workers) w.join();
        if(old_main_mask)SetThreadAffinityMask(GetCurrentThread(),old_main_mask);
    }
    FusedCpu(const FusedCpu &) = delete;
    FusedCpu & operator=(const FusedCpu &) = delete;
    void run(const float * x, const int * active, const float * route_weights,
             int n, float * out, float * per_expert = nullptr) {
        if (n < 0 || n > EMAX || !x || !out || (n && (!active || !route_weights))) throw std::runtime_error("invalid CPU job");
        for (int e=0; e<n; ++e) {
            if (active[e]<0 || active[e]>=banks.experts) throw std::runtime_error("expert id out of bounds");
            ids[e] = active[e]; weights[e] = route_weights[e];
        }
        if (n==0) { for(int r=0;r<K;++r) out[r]=0; return; }
        selected=n; output=out; individual=per_expert;
        quant_x(x,xq.data(),K);
        generation.fetch_add(1,std::memory_order_release);
        compute(0);
    }
};
}
