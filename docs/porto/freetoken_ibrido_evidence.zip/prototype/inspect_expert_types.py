import json, pathlib, sys, types
pkg=pathlib.Path(r'C:\Users\imanu\Documents\Codex\2026-09-13\rip\work\speed_target\research_prefetch\gguf-py\gguf')
mod=types.ModuleType('gguf');mod.__path__=[str(pkg)];sys.modules['gguf']=mod
from gguf.gguf_reader import GGUFReader
root=pathlib.Path(r'D:\models\qwen38flashnext\UD-IQ3_XXS')
files=sorted(root.glob('*.gguf'))
rows={}
for fn in files:
    rd=GGUFReader(str(fn))
    for t in rd.tensors:
        n=t.name
        if '.ffn_' in n and n.endswith('_exps.weight'):
            parts=n.split('.')
            layer=int(parts[1]); bank=parts[2].removesuffix('_exps')
            rows.setdefault(layer,{})[bank]={'type':int(t.tensor_type),'shape':[int(x) for x in t.shape],'shard':fn.name}
out={'source_files':[str(x) for x in files],'method':'GGUFReader tensor directory metadata only; no tensor.data/payload access','layers':rows}
out['counts']={}
for l,b in rows.items():
    key=tuple((k,v['type'],tuple(v['shape'])) for k,v in sorted(b.items()));out['counts'][str(key)]=out['counts'].get(str(key),0)+1
pathlib.Path(r'C:\Users\imanu\Documents\Codex\2026-09-13\rip\work\freetoken_hybrid\expert_layer_types.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
