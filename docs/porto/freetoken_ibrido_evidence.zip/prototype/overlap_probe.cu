#include "fused_cpu.hpp"
#include "ggml-backend-impl.h"
#include "ggml-cuda.h"
#include "fork-moe-kernels.cuh"
#include <cuda.h>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <fstream>
#include <memory>
#include <string>
using namespace hybrid_probe;
using namespace qwen_moe_demand;
using Clock=std::chrono::steady_clock;
static void ck(cudaError_t e){if(e!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(e));}
static void dc(CUresult e){if(e!=CUDA_SUCCESS){const char *s;cuGetErrorName(e,&s);throw std::runtime_error(s);}}
using MemOp=CUresult(CUDAAPI*)(CUstream,CUdeviceptr,cuuint64_t,unsigned);
static MemOp wr,wa;
constexpr int E=128,NC=128,ACTIVE=10,SLOTS=10;
struct Input {float x[K];};
struct Job {float x[K];int ids[EMAX];float weights[EMAX];float y[K];};
struct Flags {alignas(64) volatile LONG64 request=0;alignas(64) volatile LONG64 done=0;};
static void CUDART_CB request_cpu(void*p){auto*f=(Flags*)p;InterlockedExchange64(&f->request,1);}
static void CUDART_CB wait_cpu(void*p){
    auto*f=(Flags*)p;unsigned spins=0;ULONGLONG start=GetTickCount64();
    while(InterlockedCompareExchange64(&f->done,0,1)!=1){
        _mm_pause();
        if(++spins==1000000){spins=0;if(GetTickCount64()-start>10000){std::fprintf(stderr,"CPU callback timeout\n");std::abort();}}
    }
}
struct HostBanks {
    uint8_t *p[3]{};uint8_t *dev[3]{};size_t stride[3];
    HostBanks(const std::string&dir){
        stride[0]=stride[1]=ggml_row_size(GGML_TYPE_IQ2_S,K)*H;
        stride[2]=ggml_row_size(GGML_TYPE_IQ4_NL,H)*K;
        const char *names[]={"gate_22.bin","up_22.bin","down_20.bin"};
        for(int b=0;b<3;++b){
            size_t size=stride[b]*E;
            std::ifstream f(dir+"/"+names[b],std::ios::binary|std::ios::ate);
            if(!f||f.tellg()!=(std::streamoff)size)throw std::runtime_error("missing original bank");
            ck(cudaHostAlloc((void**)&p[b],size,cudaHostAllocMapped|cudaHostAllocPortable));
            ck(cudaHostGetDevicePointer((void**)&dev[b],p[b],0));
            f.seekg(0);f.read((char*)p[b],size);
        }
    }
    ~HostBanks(){for(auto p0:p)if(p0)cudaFreeHost(p0);}
};
class Coordinator {
    std::thread worker;std::atomic<bool> stop{false},ready{false};
public:
    Coordinator(HostBanks&b,Job*j,Flags*f,int n,int threads){
        worker=std::thread([&,j,f,n,threads]{
            FusedCpu cpu({b.p[0],b.p[1],b.p[2],E},threads);
            ready.store(true,std::memory_order_release);
            while(!stop.load(std::memory_order_acquire)){
                if(InterlockedCompareExchange64(&f->request,0,1)==1){
                    cpu.run(j->x,j->ids,j->weights,n,j->y);
                    InterlockedExchange64(&f->done,1);
                }else _mm_pause();
            }
        });
        while(!ready.load(std::memory_order_acquire))std::this_thread::yield();
    }
    ~Coordinator(){stop.store(true,std::memory_order_release);worker.join();}
};
// All benchmark cases and route choices originate on the device. CPU jobs are
// populated by D2H, so this includes the round trip absent from CPU-only probes.
__global__ void prepare(const Input*cases,unsigned*counter,float*x,int*ids,Job*j,
                        moe_grouped_decode_plan*plan,int missing,int cpu){
    int c=*counter%NC,hot=ACTIVE-missing,ng=ACTIVE-cpu;
    for(int k=threadIdx.x;k<K;k+=blockDim.x)x[k]=j->x[k]=cases[c].x[k];
    for(int e=threadIdx.x;e<ng;e+=blockDim.x)ids[e]=e;
    for(int e=threadIdx.x;e<cpu;e+=blockDim.x){
        j->ids[e]=16+(c*7+e*11)%112;
        j->weights[e]=(hot+e+1.f)/55.f;
    }
    for(int e=threadIdx.x;e<missing-cpu;e+=blockDim.x){
        moe_grouped_plan_array_ptr(plan,SLOTS,MOE_GROUPED_PLAN_MISS_EXPERTS)[e]=16+(c*7+(e+cpu)*11)%112;
        moe_grouped_plan_array_ptr(plan,SLOTS,MOE_GROUPED_PLAN_MISS_SLOTS)[e]=hot+e;
    }
    __syncthreads();if(threadIdx.x==0)++*counter;
}
__global__ void merge(const float*y,const float*cpu_y,float*out,int missing,int cpu){
    int hot=ACTIVE-missing,ng=ACTIVE-cpu;
    for(int k=threadIdx.x+blockIdx.x*blockDim.x;k<K;k+=blockDim.x*gridDim.x){
        float sum=0;
        for(int e=0;e<ng;++e){int route=e<hot?e:e+cpu;sum+=(route+1.f)/55.f*y[e*K+k];}
        if(cpu)sum+=cpu_y[k];out[k]=sum;
    }
}
class Layer {
    HostBanks&hb;int missing,cpu,comm;
    ggml_context*ctx=nullptr;ggml_backend_t be=nullptr;ggml_backend_buffer_t buf=nullptr;
    ggml_tensor *g,*u,*d,*x,*ids,*y;ggml_cgraph*graph;
    cudaStream_t stream{};cudaGraph_t captured{};cudaGraphExec_t exec{};
    moe_grouped_device_bank *banks{};moe_grouped_decode_plan *plan{};
    Input *cases{};unsigned *counter{};Job *jobdev{},*jobhost{},*jobmapped{};Flags*flags{};
    float *cpu_y{},*out{};std::unique_ptr<Coordinator> coordinator;
    void enqueue(){
        bool mapped=comm==1||comm==2||comm==4,callback=comm>=2;
        prepare<<<1,256,0,stream>>>(cases,counter,(float*)x->data,(int*)ids->data,cpu&&mapped?jobmapped:jobdev,plan,missing,cpu);
        if(cpu){
            if(!mapped)ck(cudaMemcpyAsync(jobhost,jobdev,offsetof(Job,y),cudaMemcpyDeviceToHost,stream));
            if(callback)ck(cudaLaunchHostFunc(stream,request_cpu,flags));
            else dc(wr((CUstream)stream,(CUdeviceptr)&flags->request,1,0));
            if(comm==4)ck(cudaLaunchHostFunc(stream,wait_cpu,flags)); // serial control
        }
        if(missing>cpu){
            size_t words=(hb.stride[0]+hb.stride[1]+hb.stride[2])/16;
            moe_grouped_gather_decode<false><<<112,256,0,stream>>>(banks,3,words,nullptr,0,0,SLOTS,plan,nullptr);
        }
        if(ggml_backend_graph_compute_async(be,graph)!=GGML_STATUS_SUCCESS)throw std::runtime_error("GPU compute failed");
        if(cpu){
            if(callback&&comm!=4)ck(cudaLaunchHostFunc(stream,wait_cpu,flags));
            else if(!callback)dc(wa((CUstream)stream,(CUdeviceptr)&flags->done,1,CU_STREAM_WAIT_VALUE_GEQ));
            if(!mapped)ck(cudaMemcpyAsync(cpu_y,jobhost->y,K*sizeof(float),cudaMemcpyHostToDevice,stream));
            if(!callback)dc(wr((CUstream)stream,(CUdeviceptr)&flags->done,0,0));
        }
        merge<<<10,256,0,stream>>>((float*)y->data,cpu&&mapped?jobmapped->y:cpu_y,out,missing,cpu);
        ck(cudaGetLastError());
    }
public:
    Layer(HostBanks&h,int m,int c,int threads,int communication=0):hb(h),missing(m),cpu(c),comm(communication){
        int ng=ACTIVE-c;
        ctx=ggml_init({4ull<<20,nullptr,true});
        g=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ2_S,K,H,SLOTS);
        u=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ2_S,K,H,SLOTS);
        d=ggml_new_tensor_3d(ctx,GGML_TYPE_IQ4_NL,H,K,SLOTS);
        x=ggml_new_tensor_3d(ctx,GGML_TYPE_F32,K,1,1);
        ids=ggml_new_tensor_2d(ctx,GGML_TYPE_I32,ng,1);
        auto hidden=ggml_mul(ctx,ggml_silu(ctx,ggml_mul_mat_id(ctx,g,x,ids)),ggml_mul_mat_id(ctx,u,x,ids));
        y=ggml_mul_mat_id(ctx,d,hidden,ids);
        graph=ggml_new_graph_custom(ctx,64,false);ggml_build_forward_expand(graph,y);
        be=ggml_backend_cuda_init(0);buf=ggml_backend_alloc_ctx_tensors(ctx,be);
        if(!buf)throw std::runtime_error("GPU alloc failed");
        ggml_tensor *t[]={g,u,d};moe_grouped_device_bank hostbanks[3]{};
        for(int b=0;b<3;++b){
            ggml_backend_tensor_set(t[b],hb.p[b],0,SLOTS*hb.stride[b]);
            hostbanks[b].data=(char*)t[b]->data;hostbanks[b].source=(char*)hb.dev[b];hostbanks[b].expert_stride=hb.stride[b];
        }
        std::vector<Input> hc(NC);for(int n=0;n<NC;++n)for(int k=0;k<K;++k)hc[n].x[k]=(n%3==0?.25f:n%3==1?1.f:4.f)*std::sin(k*.013f+n*.713f);
        int hi[ACTIVE];for(int e=0;e<ng;++e)hi[e]=e;
        ggml_backend_tensor_set(x,hc[0].x,0,K*sizeof(float));ggml_backend_tensor_set(ids,hi,0,ng*sizeof(int));
        // Warm kernel allocations before capturing the entire layer externally.
        for(int i=0;i<4;++i)if(ggml_backend_graph_compute(be,graph)!=GGML_STATUS_SUCCESS)throw std::runtime_error("GPU warmup failed");
        auto *internal=(ggml_backend_cuda_context*)be->context;
        stream=internal->streams[internal->device][internal->curr_stream_no];
        if(!stream)throw std::runtime_error("GGML stream unavailable");
        ck(cudaStreamSynchronize(stream));
        ck(cudaMalloc((void**)&banks,sizeof(hostbanks)));ck(cudaMemcpy(banks,hostbanks,sizeof(hostbanks),cudaMemcpyHostToDevice));
        size_t bytes;if(!moe_grouped_plan_size(SLOTS,E,&bytes))throw std::runtime_error("plan size failed");
        std::vector<uint8_t> hp(bytes);auto *p=(moe_grouped_decode_plan*)hp.data();p->status=MOE_GROUPED_PLAN_READY;p->n_routes=ng;p->n_unique=ng;p->n_misses=m-c;
        ck(cudaMalloc((void**)&plan,bytes));ck(cudaMemcpy(plan,hp.data(),bytes,cudaMemcpyHostToDevice));
        ck(cudaMalloc((void**)&cases,NC*sizeof(Input)));ck(cudaMemcpy(cases,hc.data(),NC*sizeof(Input),cudaMemcpyHostToDevice));
        ck(cudaMalloc((void**)&counter,sizeof(unsigned)));ck(cudaMemset(counter,0,sizeof(unsigned)));
        ck(cudaMalloc((void**)&jobdev,sizeof(Job)));ck(cudaMalloc((void**)&cpu_y,K*sizeof(float)));ck(cudaMalloc((void**)&out,K*sizeof(float)));
        if(c){
            ck(cudaHostAlloc((void**)&jobhost,sizeof(Job),cudaHostAllocPortable|cudaHostAllocMapped));
            ck(cudaHostGetDevicePointer((void**)&jobmapped,jobhost,0));
            ck(cudaHostAlloc((void**)&flags,sizeof(Flags),cudaHostAllocPortable|cudaHostAllocMapped));
            new(flags)Flags();coordinator=std::make_unique<Coordinator>(hb,jobhost,flags,c,threads);
        }
        for(int i=0;i<4;++i){enqueue();ck(cudaStreamSynchronize(stream));}
        ck(cudaStreamBeginCapture(stream,cudaStreamCaptureModeRelaxed));enqueue();ck(cudaStreamEndCapture(stream,&captured));
        ck(cudaGraphInstantiate(&exec,captured,nullptr,nullptr,0));
        reset();
    }
    void reset(){ck(cudaMemsetAsync(counter,0,sizeof(unsigned),stream));ck(cudaStreamSynchronize(stream));}
    void run(int batch,float*host=nullptr){for(int i=0;i<batch;++i)ck(cudaGraphLaunch(exec,stream));ck(cudaStreamSynchronize(stream));if(host)ck(cudaMemcpy(host,out,K*sizeof(float),cudaMemcpyDeviceToHost));}
    std::vector<double> time(int batch){
        for(int i=0;i<8;++i)run(batch);
        std::vector<double> t;for(int i=0;i<80;++i){auto begin=Clock::now();run(batch);t.push_back(std::chrono::duration<double,std::micro>(Clock::now()-begin).count()/batch);}
        return t;
    }
    ~Layer(){
        if(stream)cudaStreamSynchronize(stream);coordinator.reset();
        if(exec)cudaGraphExecDestroy(exec);if(captured)cudaGraphDestroy(captured);
        for(void*p:{(void*)banks,(void*)plan,(void*)cases,(void*)counter,(void*)jobdev,(void*)cpu_y,(void*)out})if(p)cudaFree(p);
        if(jobhost)cudaFreeHost(jobhost);if(flags)cudaFreeHost(flags);
        ggml_backend_buffer_free(buf);ggml_backend_free(be);ggml_free(ctx);
    }
};
static double pct(std::vector<double>x,double p){std::sort(x.begin(),x.end());return x[(size_t)(p*(x.size()-1))];}
int main(int argc,char**argv)try{
    int missing=argc>1?std::stoi(argv[1]):3,cpu=argc>2?std::stoi(argv[2]):1,threads=argc>3?std::stoi(argv[3]):6;
    int comm=argc>4?std::stoi(argv[4]):0;
    int reverse=argc>5?std::stoi(argv[5]):0;
    int batch=argc>6?std::stoi(argv[6]):16;
    std::string dir=argc>7?argv[7]:"../cpu_quant_audit";
    if(missing<0||missing>10||cpu<0||cpu>missing||cpu>4||threads<1||threads>8||comm<0||comm>4||reverse<0||reverse>1||batch<1||batch>64)throw std::runtime_error("invalid args");
    // Our outer graph includes transfer + compute + handshake + merge. Avoid
    // nested cudaGraphLaunch, which cannot be recorded by stream capture here.
    _putenv_s("GGML_CUDA_DISABLE_GRAPHS","1");
    ck(cudaSetDeviceFlags(cudaDeviceMapHost));ck(cudaSetDevice(0));
    HMODULE driver=LoadLibraryA("nvcuda.dll");
    wr=(MemOp)GetProcAddress(driver,"cuStreamWriteValue64_v2");wa=(MemOp)GetProcAddress(driver,"cuStreamWaitValue64_v2");
    if(!wr)wr=(MemOp)GetProcAddress(driver,"cuStreamWriteValue64");if(!wa)wa=(MemOp)GetProcAddress(driver,"cuStreamWaitValue64");
    if(!wr||!wa)throw std::runtime_error("driver stream memory operations unavailable");
    HostBanks h(dir);std::vector<float> reference(NC*K),actual(NC*K);std::vector<double> bt,ht;
    auto base=[&]{
        Layer baseline(h,missing,0,threads);
        for(int c=0;c<NC;++c)baseline.run(1,reference.data()+c*K);
        bt=baseline.time(batch);
    };
    auto candidate=[&]{
        Layer hybrid(h,missing,cpu,threads,comm);
        for(int c=0;c<NC;++c)hybrid.run(1,actual.data()+c*K);
        ht=hybrid.time(batch);
    };
    if(reverse&&cpu){candidate();base();}else{base();if(cpu)candidate();}
    if(!cpu){ht=bt;actual=reference;}
    double err=0,den=0,maxerr=0,worst_case=0;bool finite=true;
    for(int c=0;c<NC;++c){
        double ce=0,cd=0;
        for(int k=0;k<K;++k){double r=reference[c*K+k],v=actual[c*K+k],d=v-r;finite=finite&&std::isfinite(v)&&std::isfinite(r);ce+=d*d;cd+=r*r;maxerr=std::max(maxerr,std::abs(d));}
        err+=ce;den+=cd;worst_case=std::max(worst_case,std::sqrt(ce/std::max(cd,1e-30)));
    }
    double nrmse=std::sqrt(err/std::max(den,1e-30));
    std::printf("missing=%d cpu=%d threads=%d comm=%d reverse=%d cases=%d batches=80 batch_size=%d baseline_us=%.3f hybrid_us=%.3f speedup=%.4f baseline_p90_us=%.3f hybrid_p90_us=%.3f gpu_nrmse=%.7g worst_case_nrmse=%.7g gpu_maxerr=%.7g finite=%d graph=1\n",missing,cpu,threads,comm,reverse,NC,batch,pct(bt,.5),pct(ht,.5),pct(bt,.5)/pct(ht,.5),pct(bt,.9),pct(ht,.9),nrmse,worst_case,maxerr,finite?1:0);
    return !finite||worst_case>.05?3:0;
}catch(const std::exception&e){std::fprintf(stderr,"PROBE_ERROR %s\n",e.what());return 2;}
