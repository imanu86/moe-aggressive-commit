import hashlib, json, pathlib, shutil, zipfile
here=pathlib.Path(__file__).resolve().parent
root=here.parents[1]
out=root/'outputs'
qroot=pathlib.Path(r'C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean')
report=out/'FREETOKEN_IBRIDO_13_SETTEMBRE.md'
def sha(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
weights=json.loads((root/'work/cpu_quant_audit/original_weight_manifest.json').read_text())
for t in weights['tensors']:
    p=root/'work/cpu_quant_audit'/t['file']
    assert p.stat().st_size==t['extract_bytes'] and sha(p)==t['sha256'],t['name']
prototype=['README.md','fused_cpu.hpp','cpu_test.cpp','overlap_probe.cu','build.cmd','build_overlap.cmd',
           'run_overlap.py','confirm_overlap.py','summarize.py','inspect_expert_types.py',
           'package_evidence.py']
data=['fused_cpu_grid.json','fused_cpu_pinned_grid.json','overlap_grid.json','overlap_grid.log',
      'communication_grid.json','communication_grid.log','confirmation.json','confirmation.log',
      'four_core_single.log','cpu_three_check.log','cpu_two_check.log','summary.json',
      'expert_layer_types.json','trace_miss_distribution.json','build_cpu.log','build_overlap.log']
files={report.name:report}
files.update({'prototype/'+n:here/n for n in prototype})
files.update({'results/'+n:here/n for n in data})
for n in ('extract_original_weights.py','original_weight_manifest.json'):
    files['weights/'+n]=root/'work/cpu_quant_audit'/n
external=[qroot/'build/bin'/n for n in ('ggml-cpu.dll','ggml-cuda.dll','ggml-base.dll','ggml.dll')]
external += [qroot/'source/ggml'/n for n in ('include/ggml.h','include/ggml-cpu.h','src/ggml-backend-impl.h',
              'src/ggml-cuda/common.cuh','src/ggml-cuda/fork-moe-kernels.cuh')]
manifest={'date':'2026-09-13','scope':'One-layer prototype only; no end-to-end generation benchmark.',
          'hardware':{'gpu':'RTX 3060 12GB','cpu':'Ryzen 5800X','ram':'96GB DDR4','driver':'596.21','cuda_toolkit':'12.6','windows_build':'26200'},
          'input_weights_verified':True,'external_build_files':{str(p):sha(p) for p in external},
          'entries':{n:{'size':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}}
(here/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'freetoken_ibrido_evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in files.items():z.write(p,n)
    z.write(here/'manifest.json','manifest.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)+1
    for n,e in manifest['entries'].items():assert hashlib.sha256(z.read(n)).hexdigest()==e['sha256']
    assert len(json.loads(z.read('results/confirmation.json')))==45
docs=pathlib.Path(r'C:\Users\imanu\source\repos\moe-aggressive-commit\docs\porto')
shutil.copy2(report,docs/report.name)
shutil.copy2(archive,docs/archive.name)
handoff=docs/'HANDOFF_13_SETTEMBRE.md'
text=handoff.read_text(encoding='utf-8')
entry='> **Aggiornamento prototipo CPU/GPU FreeToken:** implementato e provato un esecutore CPU fuso sui pesi originali IQ2_S/IQ4_NL. La variante RAM pinnata mappata + callback, con tre miss e due esperti CPU, riduce un blocco da circa 337 a 242 µs (quattro core, mediana di tre processi); il controllo a singola invocazione è più variabile. Copie esplicite + flag invece rallentano. Sono misure di un blocco, non nuovi t/s: generazione libera ancora al precedente 25,08 t/s; obiettivo 50 aperto. Compatibilità dei formati verificata per 47/48 strati, strato 2 IQ3_S da gestire separatamente. Prototipo non integrato nel server, MTP non ancora coperto; produzione invariata. Risultati, limiti e replica: [FREETOKEN_IBRIDO_13_SETTEMBRE.md](FREETOKEN_IBRIDO_13_SETTEMBRE.md), `freetoken_ibrido_evidence.zip`.\n\n'
marker='## 0. In una pagina\n\n'
assert marker in text
if '> **Aggiornamento prototipo CPU/GPU FreeToken:**' not in text:
    handoff.write_text(text.replace(marker,marker+entry,1),encoding='utf-8')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':len(files)+1,
                  'archive_sha256':sha(archive),'weight_banks_verified':len(weights['tensors'])},indent=2))
