import json, os, pathlib, re, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
env=os.environ.copy()
env['PATH']=r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin;'+env['PATH']
rows=[]
name=sys.argv[1] if len(sys.argv)>1 else 'communication_grid'
configs=[(m,c,t,comm) for m in (1,2,3,4,6) for c in (1,2,3) if c<=m for t in (6,) for comm in (1,2)]
for m,c,t,comm in configs:
    p=subprocess.run([str(root/'overlap_probe.exe'),str(m),str(c),str(t),str(comm)],cwd=root,env=env,text=True,capture_output=True,timeout=45)
    line=next((s for s in p.stdout.splitlines() if s.startswith('missing=')),None)
    if p.returncode or not line:
        print(p.stdout,p.stderr,flush=True)
        raise RuntimeError(f'probe failed {m,c,t}: {p.returncode}')
    row={k:float(v) if any(ch in v.lower() for ch in '.e') else int(v) for k,v in re.findall(r'(\w+)=([0-9.e+-]+)',line)}
    rows.append(row)
    (root/(name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
    with (root/(name+'.log')).open('a') as f:f.write(p.stdout+p.stderr+'\n')
    print(line,flush=True)
