import collections, hashlib, json, pathlib, re, statistics
root=pathlib.Path(__file__).resolve().parent
rows=json.loads((root/'confirmation.json').read_text())
assert len(rows)==45 and all(r['finite']==1 and r['worst_case_nrmse']<.05 for r in rows)
groups=collections.defaultdict(list)
for r in rows:groups[tuple(r[k] for k in ('missing','cpu','threads','comm','batch_size'))].append(r)
out=[]
for key,rs in groups.items():
    assert len(rs)==3
    v=dict(zip(('missing','cpu','threads','comm','batch_size'),key))
    for metric in ('baseline_us','hybrid_us','speedup','baseline_p90_us','hybrid_p90_us'):
        v[metric]=statistics.median(r[metric] for r in rs)
    v['hybrid_min_us']=min(r['hybrid_us'] for r in rs)
    v['hybrid_max_us']=max(r['hybrid_us'] for r in rs)
    v['reduction_pct']=100*(1-v['hybrid_us']/v['baseline_us'])
    v['worst_case_nrmse']=max(r['worst_case_nrmse'] for r in rs)
    out.append(v)
summary={'method':'Median of 3 per-process medians; p90 refers to 80 within-process batch means, not individual-token p90.',
         'rows':out,'single_four_core':[]}
for s in (root/'four_core_single.log').read_text().splitlines():
    if s.startswith('missing='):
        summary['single_four_core'].append({k:float(v) for k,v in re.findall(r'(\w+)=([0-9.e+-]+)',s)})
assert len(summary['single_four_core'])==3
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in out:
    print('m{missing} cpu{cpu} t{threads} mode{comm} b{batch_size}: {baseline_us:.1f} -> {hybrid_us:.1f} us [{hybrid_min_us:.1f}, {hybrid_max_us:.1f}], {reduction_pct:.1f}%'.format(**r))
