"""Publish the documented plan; no build, model change, or benchmark."""
import hashlib, json, pathlib, re, shutil, zipfile
root=pathlib.Path(__file__).resolve().parents[2]
out=root/'outputs'
docs=pathlib.Path(r'C:\Users\imanu\source\repos\moe-aggressive-commit\docs\porto')
qroot=pathlib.Path(r'C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean')
names=['PIANO_CPU_GPU_14_SETTEMBRE.md','PROTOCOLLO_CPU_GPU_14_SETTEMBRE.md','REGISTRO_CPU_GPU_14_SETTEMBRE.md']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
state={'date':'2026-09-14','version':'1.0','scope':'planning_and_documentation_only',
       'plan_status':'complete','implementation_status':'not_started','current_phase':'P0',
       'goal':{'decode_free_tps':50,'decode_ms_per_accepted_token':20,'prefill_tps':400,
               'prefill_contexts_tokens':[32000,131000],'later_context_tokens':250000},
       'q4_status':'deferred','production_changed':False,'new_benchmark_runs':0,
       'next_action':'Create an isolated baseline/build, freeze prompt/token/template fixtures, and measure matched baseline variability.',
       'phases':[{'id':f'P{i}','status':'not_started','depends_on':[] if i==0 else [f'P{i-1}']} for i in range(8)],
       'primary_documents':names,
       'evidence':['FREETOKEN_IBRIDO_13_SETTEMBRE.md','freetoken_ibrido_evidence.zip',
                   'FREETOKEN_BONSAI_13_SETTEMBRE.md','freetoken_bonsai_evidence.zip'],
       'decisions':[f'D{i:02}' for i in range(1,11)]}
state['phases'][-1]['alternative_start']='documented closure of the CPU route after an inconclusive or negative matched confirmation'
(out/'stato_cpu_gpu_14settembre.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for n in names+['stato_cpu_gpu_14settembre.json']:
    shutil.copy2(out/n,docs/n)
# Make historical relative links valid from the repository copy as well.
for n in state['evidence']:
    if not (docs/n).exists() or sha(docs/n)!=sha(out/n):shutil.copy2(out/n,docs/n)
handoff=docs/'HANDOFF_13_SETTEMBRE.md'
content=handoff.read_text(encoding='utf-8')
marker='## 0. In una pagina\n\n'
entry='> **Piano del 14 settembre:** documentati [piano di integrazione CPU/GPU](PIANO_CPU_GPU_14_SETTEMBRE.md), [protocollo A/B e qualità](PROTOCOLLO_CPU_GPU_14_SETTEMBRE.md) e [registro di avanzamento](REGISTRO_CPU_GPU_14_SETTEMBRE.md). Stato: prototipo concluso, integrazione nel server ancora da avviare; prossima fase P0 (baseline isolata e prompt congelati), poi contratto della cache e ammissioni CPU/GPU prima del decode reale e di MTP. Nessun nuovo benchmark in questa sessione di pianificazione; produzione invariata, Q4 rinviato. Le soglie nel protocollo sono criteri per le prove future, non prestazioni già raggiunte.\n\n'
assert marker in content
if '> **Piano del 14 settembre:**' not in content:
    handoff.write_text(content.replace(marker,marker+entry,1),encoding='utf-8')

checked=[]
for directory in (out,docs):
    for n in names:
        text=(directory/n).read_text(encoding='utf-8')
        assert text.count('```')%2==0
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('https://','http://','#')):continue
            target=re.sub(r':\d+$','',target).strip('<>')
            p=pathlib.Path(target)
            if not p.is_absolute():p=directory/p
            assert p.exists(),(n,target)
            checked.append(str(p))
for n in names:assert sha(out/n)==sha(docs/n)

sources=[qroot/'source'/s for s in ('src/llama-graph.cpp','ggml/src/ggml-cuda/moe-demand.cuh',
         'ggml/src/ggml-cuda/fork-moe-kernels.cuh','ggml/src/ggml-cuda/ggml-cuda.cu','ggml/include/ggml.h')]
sources += [qroot/'build/bin'/s for s in ('ggml-cuda.dll','ggml-cpu.dll','llama.dll')]
files={n:out/n for n in names+['stato_cpu_gpu_14settembre.json']+state['evidence']}
files['publish_plan.py']=pathlib.Path(__file__)
manifest={'date':'2026-09-14','version':'1.0','new_tests_executed':False,'local_links_checked':len(checked),
          'entries':{n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()},
          'planning_time_source_and_binary_fingerprints':{str(p):sha(p) for p in sources},
          'note':'Fingerprints support P0 drift detection; they are not a completed source snapshot or matched baseline benchmark.'}
(out/'manifest_piano_cpu_gpu_14settembre.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
shutil.copy2(out/'manifest_piano_cpu_gpu_14settembre.json',docs/'manifest_piano_cpu_gpu_14settembre.json')
archive=out/'piano_cpu_gpu_14settembre.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in files.items():z.write(p,n)
    z.write(out/'manifest_piano_cpu_gpu_14settembre.json','manifest_piano_cpu_gpu_14settembre.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,e in manifest['entries'].items():assert hashlib.sha256(z.read(n)).hexdigest()==e['sha256']
    assert json.loads(z.read('stato_cpu_gpu_14settembre.json'))['new_benchmark_runs']==0
shutil.copy2(archive,docs/archive.name)
print(json.dumps({'documents':names,'local_links_checked':len(checked),'archive':str(archive),
                  'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
                  'current_phase':'P0 not started','canonical_directory':str(docs)},indent=2))
