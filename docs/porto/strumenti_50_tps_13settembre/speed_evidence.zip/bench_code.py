import argparse, hashlib, json, pathlib, re, time, urllib.request

ap = argparse.ArgumentParser()
ap.add_argument('--label', required=True)
ap.add_argument('--tokens', type=int, default=1024)
ap.add_argument('--thinking', choices=['on','off'], default='on')
args = ap.parse_args()
here = pathlib.Path(__file__).resolve().parent
run = here / args.label
key = re.search(r'set "API_KEY=([^"]*)"', (run/'launch.cmd').read_text()).group(1)
headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer '+key}
deadline = time.monotonic()+600
while True:
    try:
        with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8110/health',headers=headers),timeout=5) as response:
            if response.status==200:break
    except (OSError,urllib.error.HTTPError):pass
    if time.monotonic()>deadline:raise RuntimeError('Server not ready')
    time.sleep(2)
source = pathlib.Path(r'C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean\source\ggml\src\ggml-cuda\moe-demand.cuh').read_text()
jobs = [
    ('copy', 'Riscrivi INTEGRALMENTE il file seguente senza modificarlo, riga per riga. Non aggiungere commenti, non spiegare nulla, restituisci soltanto il codice.\n\n```\n'+source+'\n```'),
    ('rename', "Riscrivi INTEGRALMENTE il file seguente sostituendo ovunque l'identificatore `bound_group` con `gruppo_legato`. Lascia tutto il resto invariato, riga per riga. Non spiegare nulla, restituisci soltanto il codice.\n\n```\n"+source+'\n```'),
]
for name, prompt in jobs:
    if args.thinking == 'off': name += '_direct'
    body = {'messages': [{'role': 'user', 'content': prompt}], 'max_tokens': args.tokens,
            'temperature': 0, 'seed': 1234, 'stream': True, 'cache_prompt': False,
            'stream_options': {'include_usage': True}}
    if args.thinking == 'off': body['chat_template_kwargs'] = {'enable_thinking': False}
    req = urllib.request.Request('http://127.0.0.1:8110/v1/chat/completions', data=json.dumps(body).encode(), headers=headers)
    content, reasoning, timings = [], [], None
    start = time.perf_counter()
    first = None
    with urllib.request.urlopen(req, timeout=3600) as response:
        for raw in response:
            line = raw.decode('utf-8').strip()
            if not line.startswith('data:'): continue
            line = line[5:].strip()
            if line == '[DONE]': break
            obj = json.loads(line)
            if obj.get('timings'): timings = obj['timings']
            for ch in obj.get('choices', []):
                delta = ch.get('delta', {})
                c, r = delta.get('content') or '', delta.get('reasoning_content') or ''
                if (c or r) and first is None: first = time.perf_counter()
                content.append(c); reasoning.append(r)
    elapsed = time.perf_counter()-start
    text, thought = ''.join(content), ''.join(reasoning)
    (run/(name+'_content.txt')).write_text(text, encoding='utf-8')
    (run/(name+'_reasoning.txt')).write_text(thought, encoding='utf-8')
    lines = [x.strip() for x in text.splitlines() if len(x.strip())>12]
    expected = source if name.startswith('copy') else source.replace('bound_group','gruppo_legato')
    rec = {'label': args.label, 'job': name, 'thinking': args.thinking, 'wall_s': elapsed, 'ttft_s': first-start if first else None,
           'timings': timings, 'content_sha256': hashlib.sha256(text.encode()).hexdigest(),
           'all_text_sha256': hashlib.sha256((thought+text).encode()).hexdigest(),
           'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(), 'content_chars': len(text),
           'reasoning_chars': len(thought), 'copied_line_fraction': sum(x in expected for x in lines)/len(lines) if lines else 0}
    with (run/'code.jsonl').open('a') as out: out.write(json.dumps(rec)+'\n')
    print(json.dumps(rec), flush=True)
