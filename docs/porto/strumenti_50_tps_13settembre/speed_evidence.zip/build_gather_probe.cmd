@echo off
setlocal
set ROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean
set OUT=%~dp0bin
if not exist "%OUT%" mkdir "%OUT%"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
nvcc -std=c++17 -O2 -arch=sm_86 --use-local-env -Xcompiler="/EHsc,/MD" -I"%ROOT%\source\ggml\src" -I"%ROOT%\source\ggml\src\ggml-cuda" -I"%ROOT%\source\ggml\include" "%~dp0gather_probe.cu" -o "%OUT%\gather_probe.exe"
exit /b %ERRORLEVEL%
