from pathlib import Path
import hashlib, json, difflib, re, zipfile
here=Path(__file__).resolve().parent
root=Path(r'C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean')
out=here.parents[1]/'outputs'
out.mkdir(exist_ok=True)
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
data={'runs':{},'profile':json.loads((here/'profile_summary.json').read_text()),'binaries':{}}
for folder in sorted(here.iterdir()):
    if not folder.is_dir() or not (folder/'config.json').exists():continue
    run={'config':json.loads((folder/'config.json').read_text(encoding='utf-8-sig'))}
    for name in ['bench.jsonl','code.jsonl']:
        if (folder/name).exists():run[name]=[json.loads(x) for x in (folder/name).read_text().splitlines() if x.strip()]
    for name in ['binary_hashes.json','aborted.json','technical_direct_status.json']:
        if (folder/name).exists():run[name]=json.loads((folder/name).read_text(encoding='utf-8-sig'))
    for quality in folder.glob('prova_reale_*.json'):
        run[quality.name]=json.loads(quality.read_text(encoding='utf-8-sig'))
    data['runs'][folder.name]=run
for group in ['bin_prod','build/bin']:
    for name in ['ggml-cuda.dll','ggml-base.dll','ggml.dll','llama.dll','llama-common.dll']:
        data['binaries'][group+'/'+name]=sha(root/group/name)
original=(root/'source/ggml/src/ggml-cuda/moe-demand.cuh').read_text()
for label in [k for k in data['runs'] if k.startswith('mtp_')]:
    for job in ['copy_direct','rename_direct']:
        file=here/label/(job+'_content.txt')
        if not file.exists():continue
        content=file.read_text()
        code=re.sub(r'^```[^\n]*\n','',content)
        if code.endswith('\n```'):code=code[:-4]
        expected=original if job.startswith('copy') else original.replace('bound_group','gruppo_legato')
        prefix=0
        for a,b in zip(code,expected):
            if a!=b:break
            prefix+=1
        records=data['runs'][label].get('code.jsonl',[])
        for record in records:
            if record['job']==job:
                record['exact_source_prefix']=expected.startswith(code)
                record['matching_prefix_chars']=prefix
                record['code_chars_without_fence']=len(code)
        other=here/'mtp_base'/(job+'_content.txt')
        if label!='mtp_base' and other.exists():
            data.setdefault('code_equality',{}).setdefault(label,{})[job]=file.read_bytes()==other.read_bytes()
src=root/'source/ggml/src/ggml-cuda'
baseline=here/'gdn_probe/backup_before_tiled/gated_delta_net.cu'
patch=''.join(difflib.unified_diff(baseline.read_bytes().decode().splitlines(keepends=True),
    (src/'gated_delta_net.cu').read_bytes().decode().splitlines(keepends=True),
    fromfile='a/ggml/src/ggml-cuda/gated_delta_net.cu',tofile='b/ggml/src/ggml-cuda/gated_delta_net.cu'))
patch+=''.join(difflib.unified_diff([], (src/'gated_delta_net_tiled.cuh').read_bytes().decode().splitlines(keepends=True),
    fromfile='/dev/null',tofile='b/ggml/src/ggml-cuda/gated_delta_net_tiled.cuh'))
(out/'gdn_tiled.patch').write_bytes(patch.encode())
ngram_before=here/'ngram_probe/backup_before_fix/ngram-map.cpp'
ngram_after=root/'source/common/ngram-map.cpp'
ngram_patch=''.join(difflib.unified_diff(ngram_before.read_bytes().decode().splitlines(keepends=True),
    ngram_after.read_bytes().decode().splitlines(keepends=True),
    fromfile='a/common/ngram-map.cpp',tofile='b/common/ngram-map.cpp'))
(out/'ngram_short_draft.patch').write_bytes(ngram_patch.encode())
prefetch_patch=''
for name,rel in [('ggml-backend.cpp','ggml/src/ggml-backend.cpp'),('ggml-cuda.cu','ggml/src/ggml-cuda/ggml-cuda.cu')]:
    before=here/'prefetch_probe/backup_before_prefetch'/name
    after=root/'source'/rel
    prefetch_patch+=''.join(difflib.unified_diff(before.read_bytes().decode().splitlines(keepends=True),
        after.read_bytes().decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
(out/'prefill_staging.patch').write_bytes(prefetch_patch.encode())
before=here/'rollback_probe/backup_before_rs/common.cpp'
after=root/'source/common/common.cpp'
rs_patch=''.join(difflib.unified_diff(before.read_bytes().decode().splitlines(keepends=True),
    after.read_bytes().decode().splitlines(keepends=True),fromfile='a/common/common.cpp',tofile='b/common/common.cpp'))
(out/'ngram_rollback.patch').write_bytes(rs_patch.encode())
data['ngram_cpu_results']={p.name:p.read_text() for p in sorted((here/'ngram_probe').glob('*_result.txt'))}
if 'mtp_ngram2' in data['runs']:
    data['runs']['mtp_ngram2']['interpretation']='Invalid as an active ngram benchmark: old simple implementation rejects M=2 < N=12, so zero ngram drafts were generated. Keeps value as a control with a larger speculation state allocation.'
data['gdn_results']={p.name:p.read_text() for p in sorted((here/'gdn_probe').glob('result*.txt'))}
data['prefetch_scheduler_results']={p.name:p.read_text(encoding='utf-8-sig') for p in sorted((here/'prefetch_probe').glob('result*.txt'))}
data['rollback_config_results']=(here/'rollback_probe/result.txt').read_text(encoding='utf-8-sig')
prefetch_hashes=[]
for mode in [1,2]:
    content=(here/f'prefetch_probe/result_mode{mode}.txt').read_text(encoding='utf-8-sig')
    prefetch_hashes.append(re.findall(r'fnv64=([0-9a-f]+)',content))
data['prefetch_scheduler_hashes_equal']=len(prefetch_hashes[0])==9 and prefetch_hashes[0]==prefetch_hashes[1]
prior=json.loads((out/'cache_validation.json').read_text())['binary_hashes']
data['production_validation']={name:data['binaries'][name]==expected for name,expected in prior.items() if name.startswith('bin_prod/')}
for name,prefix in [('llama-common.dll','13648095'),('ggml-base.dll','5f4ba614'),('ggml.dll','093dcdab')]:
    data['production_validation']['bin_prod/'+name]=data['binaries']['bin_prod/'+name].startswith(prefix)
data['transfer_results']={name:(here/name).read_text() for name in ['gather_result.txt','memcpy_result.txt','gather_dmon.txt','memcpy_dmon.txt']}
data['source_baselines']={str(p.relative_to(here)):sha(p) for p in here.glob('*/backup_before*/*') if p.suffix in ['.cpp','.cu']}
(out/'speed_results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'runs':list(data['runs']),'code_equality':data.get('code_equality'),
    'code_prefix_checks':[(label,r['job'],r.get('exact_source_prefix')) for label,run in data['runs'].items() for r in run.get('code.jsonl',[]) if 'direct' in r['job']]}))
