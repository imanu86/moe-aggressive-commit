#include <cuda_runtime.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>

#include "fork-moe-kernels.cuh"

using namespace qwen_moe_demand;

static void check_cuda(cudaError_t err, const char * expr, const char * file, int line) {
    if (err != cudaSuccess) {
        std::cerr << file << ":" << line << ": " << expr << ": " << cudaGetErrorString(err) << "\n";
        std::exit(1);
    }
}
#define CUDA_CHECK_LOCAL(expr) check_cuda((expr), #expr, __FILE__, __LINE__)

static constexpr uint32_t kBanks = 3;
static constexpr uint32_t kExperts = 512;
static constexpr uint32_t kSlots = 64;
static constexpr uint32_t kMisses = 8;
static constexpr uint32_t kGridBlocks = 152;
static constexpr uint32_t kThreads = 256;
static constexpr size_t kStrides[kBanks] = { 655360, 655360, 660480 };

struct HostBank {
    char * host = nullptr;
    char * device = nullptr;
};

static uint4 expected_value(uint32_t bank, uint32_t expert, size_t word) {
    return make_uint4(0xA5000000u | (bank << 16) | expert,
                      static_cast<uint32_t>(word),
                      0x5A000000u | bank,
                      expert ^ static_cast<uint32_t>(word));
}

int main(int argc, char ** argv) {
    std::string mode = "gather";
    double seconds = 12.0;
    for (int i = 1; i < argc; ++i) {
        const std::string arg(argv[i]);
        if (arg == "--mode" && i + 1 < argc) mode = argv[++i];
        else if (arg == "--seconds" && i + 1 < argc) seconds = std::stod(argv[++i]);
        else if (arg == "--help") {
            std::cout << "usage: gather_probe --mode gather|memcpy --seconds N\n";
            return 0;
        } else {
            std::cerr << "unknown argument: " << arg << "\n";
            return 2;
        }
    }
    if (mode != "gather" && mode != "memcpy") {
        std::cerr << "--mode must be gather or memcpy\n";
        return 2;
    }

    // Must be set before the first CUDA context use for mapped-host source pointers.
    CUDA_CHECK_LOCAL(cudaSetDeviceFlags(cudaDeviceMapHost));
    cudaStream_t stream = nullptr;
    CUDA_CHECK_LOCAL(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    HostBank host[kBanks];
    moe_grouped_device_bank banks[kBanks]{};
    size_t words_per_miss = 0;
    for (uint32_t bank = 0; bank < kBanks; ++bank) {
        if (kStrides[bank] % sizeof(uint4) != 0) return 2;
        words_per_miss += kStrides[bank] / sizeof(uint4);
        const size_t bytes = kStrides[bank] * kExperts;
        CUDA_CHECK_LOCAL(cudaHostAlloc(reinterpret_cast<void **>(&host[bank].host), bytes,
                                       cudaHostAllocMapped | cudaHostAllocPortable));
        CUDA_CHECK_LOCAL(cudaHostGetDevicePointer(reinterpret_cast<void **>(&host[bank].device),
                                                   host[bank].host, 0));
        uint4 * values = reinterpret_cast<uint4 *>(host[bank].host);
        const size_t words = kStrides[bank] / sizeof(uint4);
        for (uint32_t expert = 0; expert < kExperts; ++expert) {
            for (size_t word = 0; word < words; ++word) values[static_cast<size_t>(expert) * words + word] = expected_value(bank, expert, word);
        }
        CUDA_CHECK_LOCAL(cudaMalloc(reinterpret_cast<void **>(&banks[bank].data), kStrides[bank] * kSlots));
        banks[bank].source = host[bank].device;
        banks[bank].expert_stride = kStrides[bank];
    }

    moe_grouped_decode_plan * plan_host = nullptr;
    size_t plan_bytes = 0;
    if (!moe_grouped_plan_size(kSlots, kExperts, &plan_bytes)) return 2;
    CUDA_CHECK_LOCAL(cudaHostAlloc(reinterpret_cast<void **>(&plan_host), plan_bytes, cudaHostAllocPortable));
    std::memset(plan_host, 0, plan_bytes);
    plan_host->status = MOE_GROUPED_PLAN_READY;
    plan_host->n_routes = kMisses;
    plan_host->n_unique = kMisses;
    plan_host->n_misses = kMisses;
    for (uint32_t i = 0; i < kMisses; ++i) {
        moe_grouped_plan_array_ptr(plan_host, kSlots, MOE_GROUPED_PLAN_MISS_EXPERTS)[i] = static_cast<int32_t>(i);
        moe_grouped_plan_array_ptr(plan_host, kSlots, MOE_GROUPED_PLAN_MISS_SLOTS)[i] = static_cast<int32_t>(i);
    }
    moe_grouped_device_bank * banks_device = nullptr;
    moe_grouped_decode_plan * plan_device = nullptr;
    CUDA_CHECK_LOCAL(cudaMalloc(reinterpret_cast<void **>(&banks_device), sizeof(banks)));
    CUDA_CHECK_LOCAL(cudaMalloc(reinterpret_cast<void **>(&plan_device), plan_bytes));
    CUDA_CHECK_LOCAL(cudaMemcpy(banks_device, banks, sizeof(banks), cudaMemcpyHostToDevice));
    CUDA_CHECK_LOCAL(cudaMemcpy(plan_device, plan_host, plan_bytes, cudaMemcpyHostToDevice));

    const size_t bytes_per_iteration = static_cast<size_t>(kMisses) * (kStrides[0] + kStrides[1] + kStrides[2]);
    // One synchronized batch bounds queue depth while amortizing host synchronization.
    CUDA_CHECK_LOCAL(cudaStreamSynchronize(stream));
    const auto begin = std::chrono::steady_clock::now();
    uint64_t iterations = 0;
    while (true) {
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<double>(now - begin).count() >= seconds) break;
        const uint32_t batch = 100;
        for (uint32_t b = 0; b < batch; ++b) {
            if (mode == "gather") {
                moe_grouped_gather_decode<false><<<kGridBlocks, kThreads, 0, stream>>>(
                    banks_device, kBanks, words_per_miss, nullptr, 0, 0, kSlots, plan_device, nullptr);
            } else {
                for (uint32_t miss = 0; miss < kMisses; ++miss) {
                    for (uint32_t bank = 0; bank < kBanks; ++bank) {
                        CUDA_CHECK_LOCAL(cudaMemcpyAsync(
                            banks[bank].data + static_cast<size_t>(miss) * kStrides[bank],
                            host[bank].host + static_cast<size_t>(miss) * kStrides[bank],
                            kStrides[bank], cudaMemcpyHostToDevice, stream));
                    }
                }
            }
        }
        CUDA_CHECK_LOCAL(cudaStreamSynchronize(stream));
        if (mode == "gather") CUDA_CHECK_LOCAL(cudaGetLastError());
        iterations += batch;
    }
    const auto end = std::chrono::steady_clock::now();
    const double elapsed = std::chrono::duration<double>(end - begin).count();

    bool valid = true;
    for (uint32_t bank = 0; bank < kBanks; ++bank) {
        const size_t words = kStrides[bank] / sizeof(uint4);
        uint4 * observed = new uint4[words * kMisses];
        CUDA_CHECK_LOCAL(cudaMemcpy(observed, banks[bank].data, kStrides[bank] * kMisses,
                                   cudaMemcpyDeviceToHost));
        for (uint32_t expert = 0; expert < kMisses; ++expert) {
            for (size_t word = 0; word < words; ++word) {
                const uint4 expected = expected_value(bank, expert, word);
                if (std::memcmp(&observed[expert * words + word], &expected, sizeof(expected))) valid = false;
            }
        }
        delete[] observed;
    }
    std::cout << "mode=" << mode << " iterations=" << iterations << " bytes="
              << (static_cast<unsigned long long>(iterations) * bytes_per_iteration)
              << " elapsed_s=" << elapsed << " GBps="
              << (static_cast<double>(iterations) * bytes_per_iteration / elapsed / 1.0e9)
              << " last_segment=" << (valid ? "ok" : "MISMATCH") << "\n";

    CUDA_CHECK_LOCAL(cudaFree(plan_device));
    CUDA_CHECK_LOCAL(cudaFree(banks_device));
    CUDA_CHECK_LOCAL(cudaFreeHost(plan_host));
    for (uint32_t bank = 0; bank < kBanks; ++bank) {
        CUDA_CHECK_LOCAL(cudaFree(banks[bank].data));
        CUDA_CHECK_LOCAL(cudaFreeHost(host[bank].host));
    }
    CUDA_CHECK_LOCAL(cudaStreamDestroy(stream));
    return valid ? 0 : 1;
}
