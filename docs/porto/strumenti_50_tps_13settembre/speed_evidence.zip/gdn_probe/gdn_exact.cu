// MIT: llama.cpp contributors and pwilkin/llama.cpp commit 964c6f2f0.
// Exact local baseline; upstream tiled kernel with CUDA warp reduction.
#include "ggml-cuda/common.cuh"
#include <random>
#include <vector>
#include <cmath>
template <int S_v, bool KDA, bool keep_rs_t>
__global__ void __launch_bounds__((ggml_cuda_get_physical_warp_size() < S_v ? ggml_cuda_get_physical_warp_size() : S_v) * 4, 2)
gated_delta_net_cuda(const float * q,
                                     const float * k,
                                     const float * v,
                                     const float * g,
                                     const float * beta,
                                     const float * curr_state,
                                     float *       dst,
                                     float *       state,
                                     int64_t       H,
                                     int64_t       n_tokens,
                                     int64_t       n_seqs,
                                     int64_t       sq1,
                                     int64_t       sq2,
                                     int64_t       sq3,
                                     int64_t       sv1,
                                     int64_t       sv2,
                                     int64_t       sv3,
                                     int64_t       sb1,
                                     int64_t       sb2,
                                     int64_t       sb3,
                                     const uint3   neqk1_magic,
                                     const uint3   rq3_magic,
                                     float         scale,
                                     int64_t       state_slot_stride,
                                     int           K) {
    const uint32_t h_idx    = blockIdx.x;
    const uint32_t sequence = blockIdx.y;
    // each warp owns one column, using warp-level primitives to reduce across rows
    const int      lane     = threadIdx.x;
    const int      col      = blockIdx.z * blockDim.y + threadIdx.y;

    const uint32_t iq1 = fastmodulo(h_idx, neqk1_magic);
    const uint32_t iq3 = fastdiv(sequence, rq3_magic);

    float *       attn_data        = dst;

    // input state holds s0 only: [S_v, S_v, H, n_seqs] — seq stride is D = H * S_v * S_v.
    // output state layout (per-slot D * n_seqs) — same per-(seq,head) offset as before.
    const int64_t state_in_offset      = sequence * H * S_v * S_v + h_idx * S_v * S_v;
    const int64_t state_out_offset     = (sequence * H + h_idx) * S_v * S_v;
    state += state_out_offset;
    curr_state += state_in_offset + col * S_v;
    attn_data += (sequence * n_tokens * H + h_idx) * S_v;

    constexpr int warp_size = ggml_cuda_get_physical_warp_size() < S_v ? ggml_cuda_get_physical_warp_size() : S_v;
    static_assert(S_v % warp_size == 0, "S_v must be a multiple of warp_size");
    constexpr int rows_per_lane = (S_v + warp_size - 1) / warp_size;
    float         s_shard[rows_per_lane];
    // state is stored transposed: M[col][i] = S[i][col], row col is contiguous

    ggml_cuda_pdl_sync();
#pragma unroll
    for (int r = 0; r < rows_per_lane; r++) {
        const int i = r * warp_size + lane;
        s_shard[r]  = curr_state[i];
    }

    for (int t = 0; t < n_tokens; t++) {
        const float * q_t = q + iq3 * sq3 + t * sq2 + iq1 * sq1;
        const float * k_t = k + iq3 * sq3 + t * sq2 + iq1 * sq1;
        const float * v_t = v + sequence * sv3 + t * sv2 + h_idx * sv1;

        const int64_t gb_offset = sequence * sb3 + t * sb2 + h_idx * sb1;
        const float * beta_t = beta + gb_offset;
        const float * g_t    = g    + gb_offset * (KDA ? S_v : 1);

        const float beta_val = *beta_t;

        // Cache k and q in registers
        float k_reg[rows_per_lane];
        float q_reg[rows_per_lane];
#pragma unroll
        for (int r = 0; r < rows_per_lane; r++) {
            const int i = r * warp_size + lane;
            k_reg[r] = k_t[i];
            q_reg[r] = q_t[i];
        }

        if constexpr (!KDA) {
            const float g_val = expf(*g_t);

            // kv[col] = (S^T @ k)[col] = sum_i S[i][col] * k[i]
            float kv_shard = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                kv_shard += s_shard[r] * k_reg[r];
            }
            float kv_col = warp_reduce_sum<warp_size>(kv_shard);

            // delta[col] = (v[col] - g * kv[col]) * beta
            float delta_col = (v_t[col] - g_val * kv_col) * beta_val;

            // fused: S[i][col] = g * S[i][col] + k[i] * delta[col]
            // attn[col] = (S^T @ q)[col] = sum_i S[i][col] * q[i]
            float attn_partial = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                s_shard[r]  = g_val * s_shard[r] + k_reg[r] * delta_col;
                attn_partial += s_shard[r] * q_reg[r];
            }

            float attn_col = warp_reduce_sum<warp_size>(attn_partial);

            if (lane == 0) {
                attn_data[col] = attn_col * scale;
            }
        } else {
            // kv[col] = sum_i g[i] * S[i][col] * k[i]
            float kv_shard = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                const int i = r * warp_size + lane;
                kv_shard += expf(g_t[i]) * s_shard[r] * k_reg[r];
            }

            float kv_col = warp_reduce_sum<warp_size>(kv_shard);

            // delta[col] = (v[col] - kv[col]) * beta
            float delta_col = (v_t[col] - kv_col) * beta_val;

            // fused: S[i][col] = g[i] * S[i][col] + k[i] * delta[col]
            // attn[col] = (S^T @ q)[col] = sum_i S[i][col] * q[i]
            float attn_partial = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                const int i = r * warp_size + lane;
                s_shard[r]  = expf(g_t[i]) * s_shard[r] + k_reg[r] * delta_col;
                attn_partial += s_shard[r] * q_reg[r];
            }

            float attn_col = warp_reduce_sum<warp_size>(attn_partial);

            if (lane == 0) {
                attn_data[col] = attn_col * scale;
            }
        }

        attn_data += S_v * H;

        if constexpr (keep_rs_t) {
            // snapshot slot mapping: slot 0 = most recent state, slot s = s tokens back.
            // When n_tokens < K only slots 0..n_tokens-1 are written; older slots are caller-owned.
            const int target_slot = (int) n_tokens - 1 - t;
            if (target_slot >= 0 && target_slot < K) {
                float * curr_state = state + target_slot * state_slot_stride;
#pragma unroll
                for (int r = 0; r < rows_per_lane; r++) {
                    const int i = r * warp_size + lane;
                    curr_state[col * S_v + i] = s_shard[r];
                }
            }
        }
    }

    if constexpr (!keep_rs_t) {
#pragma unroll
        for (int r = 0; r < rows_per_lane; r++) {
            const int i          = r * warp_size + lane;
            state[col * S_v + i] = s_shard[r];
        }
    }
}

template <int S_v, int NUM_WARPS, int COLS, int TOKEN_TILE, bool keep_rs_t>
__global__ void __launch_bounds__(32 * NUM_WARPS, 1)
gated_delta_net_tiled_cuda(const float * q,
                           const float * k,
                           const float * v,
                           const float * g,
                           const float * beta,
                           const float * curr_state,
                           float *       dst,
                           float *       state,
                           int64_t       H,
                           int64_t       n_tokens,
                           int64_t       sq1,
                           int64_t       sq2,
                           int64_t       sq3,
                           int64_t       sv1,
                           int64_t       sv2,
                           int64_t       sv3,
                           int64_t       sb1,
                           int64_t       sb2,
                           int64_t       sb3,
                           const uint3   neqk1_magic,
                           const uint3   rq3_magic,
                           float         scale,
                           int64_t       state_slot_stride,
                           int           K) {
    constexpr int warp_size     = 32;
    constexpr int rows_per_lane = S_v / warp_size;
    constexpr int block_cols    = NUM_WARPS * COLS;
    static_assert(S_v % warp_size == 0, "S_v must be a multiple of the warp size");
    static_assert(S_v % block_cols == 0, "block columns must divide S_v");

    __shared__ float q_shared[TOKEN_TILE][S_v];
    __shared__ float k_shared[TOKEN_TILE][S_v];
    __shared__ float v_shared[TOKEN_TILE][block_cols];
    __shared__ float g_shared[TOKEN_TILE];
    __shared__ float beta_shared[TOKEN_TILE];

    const uint32_t h_idx    = blockIdx.x;
    const uint32_t sequence = blockIdx.y;
    const int      lane     = threadIdx.x;
    const int      col0     = blockIdx.z * block_cols;          // first column of the block
    const int      colw     = threadIdx.y * COLS;               // first column of this warp inside the block
    const int      thread   = threadIdx.y * warp_size + lane;
    constexpr int  nthreads = NUM_WARPS * warp_size;

    const uint32_t iq1 = fastmodulo(h_idx, neqk1_magic);
    const uint32_t iq3 = fastdiv(sequence, rq3_magic);

    const int64_t state_in_offset  = sequence * H * S_v * S_v + h_idx * S_v * S_v;
    const int64_t state_out_offset = (sequence * H + h_idx) * S_v * S_v;
    state += state_out_offset;
    curr_state += state_in_offset + (col0 + colw) * S_v;
    float * attn_data = dst + (sequence * n_tokens * H + h_idx) * S_v + col0 + colw;

    float s_shard[COLS][rows_per_lane];

#pragma unroll
    for (int c = 0; c < COLS; c++) {
#pragma unroll
        for (int r = 0; r < rows_per_lane; r++) {
            s_shard[c][r] = curr_state[c * S_v + r * warp_size + lane];
        }
    }

    for (int t0 = 0; t0 < n_tokens; t0 += TOKEN_TILE) {
        const int tile_size = min((int64_t) TOKEN_TILE, n_tokens - t0);

        for (int idx = thread; idx < tile_size * S_v; idx += nthreads) {
            const int tt = idx / S_v;
            const int i  = idx % S_v;
            const int t  = t0 + tt;
            q_shared[tt][i] = q[iq3 * sq3 + t * sq2 + iq1 * sq1 + i];
            k_shared[tt][i] = k[iq3 * sq3 + t * sq2 + iq1 * sq1 + i];
        }
        for (int idx = thread; idx < tile_size * block_cols; idx += nthreads) {
            const int tt = idx / block_cols;
            const int c  = idx % block_cols;
            const int t  = t0 + tt;
            v_shared[tt][c] = v[sequence * sv3 + t * sv2 + h_idx * sv1 + col0 + c];
        }
        if (thread < tile_size) {
            const int64_t gb_offset = sequence * sb3 + (t0 + thread) * sb2 + h_idx * sb1;
            g_shared[thread]    = g[gb_offset];
            beta_shared[thread] = beta[gb_offset];
        }
        __syncthreads();

        for (int tt = 0; tt < tile_size; ++tt) {
            const int t = t0 + tt;

            float k_reg[rows_per_lane];
            float q_reg[rows_per_lane];
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                const int i = r * warp_size + lane;
                k_reg[r] = k_shared[tt][i];
                q_reg[r] = q_shared[tt][i];
            }

            const float g_val    = expf(g_shared[tt]);
            const float beta_val = beta_shared[tt];

            float attn_col[COLS];
#pragma unroll
            for (int c = 0; c < COLS; c++) {
                // kv[col] = (S^T @ k)[col] = sum_i S[i][col] * k[i]
                float kv_shard = 0.0f;
#pragma unroll
                for (int r = 0; r < rows_per_lane; r++) {
                    kv_shard = fmaf(s_shard[c][r], k_reg[r], kv_shard);
                }
                const float kv_col = warp_reduce_sum<warp_size>(kv_shard);

                // delta[col] = (v[col] - g * kv[col]) * beta
                const float delta_col = fmaf(-g_val, kv_col, v_shared[tt][colw + c]) * beta_val;

                // fused: S[i][col] = g * S[i][col] + k[i] * delta[col]
                // attn[col] = (S^T @ q)[col] = sum_i S[i][col] * q[i]
                float attn_partial = 0.0f;
#pragma unroll
                for (int r = 0; r < rows_per_lane; r++) {
                    s_shard[c][r] = fmaf(g_val, s_shard[c][r], k_reg[r] * delta_col);
                    attn_partial  = fmaf(s_shard[c][r], q_reg[r], attn_partial);
                }
                attn_col[c] = warp_reduce_sum<warp_size>(attn_partial);
            }

            if (lane < COLS) {
                float a = attn_col[0];
#pragma unroll
                for (int c = 1; c < COLS; c++) {
                    a = lane == c ? attn_col[c] : a;
                }
                attn_data[(int64_t) t * S_v * H + lane] = a * scale;
            }

            if constexpr (keep_rs_t) {
                const int target_slot = (int) n_tokens - 1 - t;
                if (target_slot >= 0 && target_slot < K) {
                    float * snapshot = state + target_slot * state_slot_stride + (col0 + colw) * S_v;
#pragma unroll
                    for (int c = 0; c < COLS; c++) {
#pragma unroll
                        for (int r = 0; r < rows_per_lane; r++) {
                            snapshot[c * S_v + r * warp_size + lane] = s_shard[c][r];
                        }
                    }
                }
            }
        }
        __syncthreads();
    }

    if constexpr (!keep_rs_t) {
#pragma unroll
        for (int c = 0; c < COLS; c++) {
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                state[(col0 + colw + c) * S_v + r * warp_size + lane] = s_shard[c][r];
            }
        }
    }
}

constexpr int S=128, H=48, HQ=16;
#define CK(x) do { cudaError_t e=(x); if(e!=cudaSuccess) {fprintf(stderr,"%s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e));exit(2);} } while(0)
int main(int argc, char **argv) {
    const int K=argc>1?atoi(argv[1]):1;
    if(K<1||K>5)return 2;
    const int vs2=argc>2?S*(H+2*HQ):S*H;
    const int voff=argc>2?2*S*HQ:0;
    std::mt19937 rng(12345);
    std::uniform_real_distribution<float> dist(-1,1);
    for (int T : {16,17,256,2048,4096,8192}) {
        const size_t nq=size_t(S)*HQ*T, nv=size_t(S)*H*T, ng=size_t(H)*T, ns=size_t(H)*S*S;
        std::vector<float> q(nq), k(nq), v(size_t(vs2)*T), g(ng), b(ng), initial(ns);
        for (auto * a : {&q,&k,&v,&g,&b,&initial}) for (float & x : *a) x=dist(rng);
        for (auto * a : {&q,&k}) for (size_t row=0; row<nq/S; ++row) {
            double norm=0;
            for (int i=0;i<S;++i) norm+=double((*a)[row*S+i])*(*a)[row*S+i];
            for (int i=0;i<S;++i) (*a)[row*S+i]/=std::sqrt(norm);
        }
        for (size_t i=0;i<ng;++i) { g[i]=-std::abs(g[i])-0.001f; b[i]=0.5f*(b[i]+1); }
        for (float & x : initial) x*=0.05f;
        float *dq,*dk,*dv,*dg,*db,*di,*o0,*o1,*s0,*s1;
        auto alloc=[](float **p,size_t n){CK(cudaMalloc(p,n*sizeof(float)));};
        auto copy=[](float *p,const std::vector<float>&a){CK(cudaMemcpy(p,a.data(),a.size()*sizeof(float),cudaMemcpyHostToDevice));};
        alloc(&dq,nq);alloc(&dk,nq);alloc(&dv,v.size());alloc(&dg,ng);alloc(&db,ng);alloc(&di,ns);
        alloc(&o0,nv);alloc(&o1,nv);alloc(&s0,ns*K);alloc(&s1,ns*K);
        copy(dq,q);copy(dk,k);copy(dv,v);copy(dg,g);copy(db,b);copy(di,initial);
        CK(cudaMemset(o0,255,nv*4));CK(cudaMemset(o1,255,nv*4));CK(cudaMemset(s0,255,ns*K*4));CK(cudaMemset(s1,255,ns*K*4));
        auto launch=[&](bool tile) {
            if (tile && K>1) gated_delta_net_tiled_cuda<128,8,8,16,true><<<dim3(H,1,2),dim3(32,8)>>>(
                dq,dk,dv+voff,dg,db,di,o1,s1,H,T,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,K);
            else if (!tile && K>1) gated_delta_net_cuda<128,false,true><<<dim3(H,1,32),dim3(32,4)>>>(
                dq,dk,dv+voff,dg,db,di,o0,s0,H,T,1,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,K);
            else if (tile) gated_delta_net_tiled_cuda<128,8,8,16,false><<<dim3(H,1,2),dim3(32,8)>>>(
                dq,dk,dv+voff,dg,db,di,o1,s1,H,T,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,1);
            else gated_delta_net_cuda<128,false,false><<<dim3(H,1,32),dim3(32,4)>>>(
                dq,dk,dv+voff,dg,db,di,o0,s0,H,T,1,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,1);
            CK(cudaGetLastError());
        };
        launch(false);launch(true);CK(cudaDeviceSynchronize());
        std::vector<float> a(nv),c(nv);
        auto compare=[&](float *p,float *r,size_t n,const char *label) {
            a.resize(n);c.resize(n);
            CK(cudaMemcpy(a.data(),p,n*4,cudaMemcpyDeviceToHost));CK(cudaMemcpy(c.data(),r,n*4,cudaMemcpyDeviceToHost));
            double maxabs=0,maxrel=0;size_t bad=0;
            for (size_t i=0;i<n;++i) {
                double d=std::abs(double(a[i])-c[i]);
                if (!std::isfinite(a[i]) || !std::isfinite(c[i]) || d>1e-5+1e-4*std::abs(double(a[i]))) ++bad;
                maxabs=std::max(maxabs,d);maxrel=std::max(maxrel,d/(std::abs(double(a[i]))+1e-6));
            }
            printf("T=%d %s maxabs=%.9g maxrel=%.9g bad=%zu\n",T,label,maxabs,maxrel,bad);
            if (bad) exit(3);
        };
        compare(o0,o1,nv,"output");compare(s0,s1,ns*K,"state");
        auto time=[&](bool tile) {
            for(int i=0;i<3;++i)launch(tile);
            cudaEvent_t beg,end;CK(cudaEventCreate(&beg));CK(cudaEventCreate(&end));
            CK(cudaEventRecord(beg));for(int i=0;i<10;++i)launch(tile);CK(cudaEventRecord(end));CK(cudaEventSynchronize(end));
            float ms=0;CK(cudaEventElapsedTime(&ms,beg,end));CK(cudaEventDestroy(beg));CK(cudaEventDestroy(end));return ms/10;
        };
        float before=time(false),after=time(true);
        printf("T=%d baseline_ms=%.6f tiled_ms=%.6f speedup=%.4f\n",T,before,after,before/after);fflush(stdout);
        for (float *p : {dq,dk,dv,dg,db,di,o0,o1,s0,s1}) CK(cudaFree(p));
    }
}
