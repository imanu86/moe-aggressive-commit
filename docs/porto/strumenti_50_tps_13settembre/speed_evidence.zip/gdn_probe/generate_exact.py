from pathlib import Path
here = Path(__file__).resolve().parent
root = Path(r'C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean')
local = (root/'source/ggml/src/ggml-cuda/gated_delta_net.cu').read_text()
remote = (here.parent/'research_gdn/gated_delta_net_964c6f2f0.cu').read_text()
baseline = local[local.index('template <int S_v, bool KDA'):local.index('template <bool KDA, bool keep_rs_t>')]
start = remote.index('template <int S_v, int NUM_WARPS, int COLS, int TOKEN_TILE, bool keep_rs_t>')
end = remote.index('\ntemplate <bool KDA, bool keep_rs_t>', start)
tiled = remote[start:end].replace('gdn_warp_reduce_sum<', 'warp_reduce_sum<')
main = r'''
constexpr int S=128, H=48, HQ=16;
#define CK(x) do { cudaError_t e=(x); if(e!=cudaSuccess) {fprintf(stderr,"%s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e));exit(2);} } while(0)
int main(int argc, char **argv) {
    const int K=argc>1?atoi(argv[1]):1;
    if(K<1||K>5)return 2;
    const int vs2=argc>2?S*(H+2*HQ):S*H;
    const int voff=argc>2?2*S*HQ:0;
    std::mt19937 rng(12345);
    std::uniform_real_distribution<float> dist(-1,1);
    for (int T : {16,17,256,2048,4096,8192}) {
        const size_t nq=size_t(S)*HQ*T, nv=size_t(S)*H*T, ng=size_t(H)*T, ns=size_t(H)*S*S;
        std::vector<float> q(nq), k(nq), v(size_t(vs2)*T), g(ng), b(ng), initial(ns);
        for (auto * a : {&q,&k,&v,&g,&b,&initial}) for (float & x : *a) x=dist(rng);
        for (auto * a : {&q,&k}) for (size_t row=0; row<nq/S; ++row) {
            double norm=0;
            for (int i=0;i<S;++i) norm+=double((*a)[row*S+i])*(*a)[row*S+i];
            for (int i=0;i<S;++i) (*a)[row*S+i]/=std::sqrt(norm);
        }
        for (size_t i=0;i<ng;++i) { g[i]=-std::abs(g[i])-0.001f; b[i]=0.5f*(b[i]+1); }
        for (float & x : initial) x*=0.05f;
        float *dq,*dk,*dv,*dg,*db,*di,*o0,*o1,*s0,*s1;
        auto alloc=[](float **p,size_t n){CK(cudaMalloc(p,n*sizeof(float)));};
        auto copy=[](float *p,const std::vector<float>&a){CK(cudaMemcpy(p,a.data(),a.size()*sizeof(float),cudaMemcpyHostToDevice));};
        alloc(&dq,nq);alloc(&dk,nq);alloc(&dv,v.size());alloc(&dg,ng);alloc(&db,ng);alloc(&di,ns);
        alloc(&o0,nv);alloc(&o1,nv);alloc(&s0,ns*K);alloc(&s1,ns*K);
        copy(dq,q);copy(dk,k);copy(dv,v);copy(dg,g);copy(db,b);copy(di,initial);
        CK(cudaMemset(o0,255,nv*4));CK(cudaMemset(o1,255,nv*4));CK(cudaMemset(s0,255,ns*K*4));CK(cudaMemset(s1,255,ns*K*4));
        auto launch=[&](bool tile) {
            if (tile && K>1) gated_delta_net_tiled_cuda<128,8,8,16,true><<<dim3(H,1,2),dim3(32,8)>>>(
                dq,dk,dv+voff,dg,db,di,o1,s1,H,T,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,K);
            else if (!tile && K>1) gated_delta_net_cuda<128,false,true><<<dim3(H,1,32),dim3(32,4)>>>(
                dq,dk,dv+voff,dg,db,di,o0,s0,H,T,1,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,K);
            else if (tile) gated_delta_net_tiled_cuda<128,8,8,16,false><<<dim3(H,1,2),dim3(32,8)>>>(
                dq,dk,dv+voff,dg,db,di,o1,s1,H,T,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,1);
            else gated_delta_net_cuda<128,false,false><<<dim3(H,1,32),dim3(32,4)>>>(
                dq,dk,dv+voff,dg,db,di,o0,s0,H,T,1,S,S*HQ,S*HQ*T,S,vs2,vs2*T,1,H,H*T,
                init_fastdiv_values(HQ),init_fastdiv_values(1),1.0f/std::sqrt(float(S)),ns,1);
            CK(cudaGetLastError());
        };
        launch(false);launch(true);CK(cudaDeviceSynchronize());
        std::vector<float> a(nv),c(nv);
        auto compare=[&](float *p,float *r,size_t n,const char *label) {
            a.resize(n);c.resize(n);
            CK(cudaMemcpy(a.data(),p,n*4,cudaMemcpyDeviceToHost));CK(cudaMemcpy(c.data(),r,n*4,cudaMemcpyDeviceToHost));
            double maxabs=0,maxrel=0;size_t bad=0;
            for (size_t i=0;i<n;++i) {
                double d=std::abs(double(a[i])-c[i]);
                if (!std::isfinite(a[i]) || !std::isfinite(c[i]) || d>1e-5+1e-4*std::abs(double(a[i]))) ++bad;
                maxabs=std::max(maxabs,d);maxrel=std::max(maxrel,d/(std::abs(double(a[i]))+1e-6));
            }
            printf("T=%d %s maxabs=%.9g maxrel=%.9g bad=%zu\n",T,label,maxabs,maxrel,bad);
            if (bad) exit(3);
        };
        compare(o0,o1,nv,"output");compare(s0,s1,ns*K,"state");
        auto time=[&](bool tile) {
            for(int i=0;i<3;++i)launch(tile);
            cudaEvent_t beg,end;CK(cudaEventCreate(&beg));CK(cudaEventCreate(&end));
            CK(cudaEventRecord(beg));for(int i=0;i<10;++i)launch(tile);CK(cudaEventRecord(end));CK(cudaEventSynchronize(end));
            float ms=0;CK(cudaEventElapsedTime(&ms,beg,end));CK(cudaEventDestroy(beg));CK(cudaEventDestroy(end));return ms/10;
        };
        float before=time(false),after=time(true);
        printf("T=%d baseline_ms=%.6f tiled_ms=%.6f speedup=%.4f\n",T,before,after,before/after);fflush(stdout);
        for (float *p : {dq,dk,dv,dg,db,di,o0,o1,s0,s1}) CK(cudaFree(p));
    }
}
'''
header = '// MIT: llama.cpp contributors and pwilkin/llama.cpp commit 964c6f2f0.\n// Exact local baseline; upstream tiled kernel with CUDA warp reduction.\n#include "ggml-cuda/common.cuh"\n#include <random>\n#include <vector>\n#include <cmath>\n'
(here/'gdn_exact.cu').write_text(header+baseline+tiled+main)
build = (here.parent/'build_gather_probe.cmd').read_text().replace('%~dp0gather_probe.cu','%~dp0gdn_exact.cu').replace('gather_probe.exe','gdn_exact.exe').replace(' -o ', ' "%ROOT%\\build\\ggml\\src\\ggml-base.lib" -o ')
(here/'build_exact.cmd').write_text(build)
print('Generated exact kernels and build script')
