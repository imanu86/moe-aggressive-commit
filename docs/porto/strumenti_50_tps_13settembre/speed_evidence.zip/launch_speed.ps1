param(
    [Parameter(Mandatory=$true)][string]$Label,
    [int]$Batch=2048,
    [int]$Mtp=0,
    [int]$Slots=64,
    [int]$Sfa=1,
    [string]$Specs='draft-mtp',
    [int]$NgramM=2,
    [int]$GdnTiled=0,
    [int]$Prefetch=0,
    [int]$NgramRollback=0,
    [switch]$Nsight
)
$ErrorActionPreference='Stop'
if(Get-Process llama-server -ErrorAction SilentlyContinue){throw 'Un server e gia attivo'}
if($Label -notmatch '^[a-z0-9_]+$'){throw 'Etichetta non valida'}
$runDir=Join-Path $PSScriptRoot $Label
New-Item -ItemType Directory -Force -Path $runDir,(Join-Path $runDir 'logs'),(Join-Path $runDir 'slots') | Out-Null
$text=Get-Content -LiteralPath 'C:\Users\imanu\Desktop\avvia Qwen38 SPERIMENTALE.bat' -Raw
$text=$text.Replace('set "HOST=0.0.0.0"','set "HOST=127.0.0.1"').Replace('set "PORT=8100"','set "PORT=8110"')
$text=[regex]::Replace($text,'(?m)^set "LOGDIR=.*$',('set "LOGDIR='+$runDir+'\logs"'))
$text=[regex]::Replace($text,'(?m)^set "SLOTDIR=.*$',('set "SLOTDIR='+$runDir+'\slots"'))
$text=[regex]::Replace($text,'(?m)^\s*pause\s*$','')
$text=$text.Replace('-b 2048','-b '+$Batch).Replace('-ub 2048','-ub '+$Batch)
if($Specs -match 'ngram-simple') {
    $text=$text.Replace('--spec-type "%SPEC_TYPES%"','--spec-type "%SPEC_TYPES%" --spec-ngram-simple-size-n 12 --spec-ngram-simple-size-m '+$NgramM+' --spec-ngram-simple-min-hits 1')
}
if($Nsight) {
    $nsys='C:\Program Files\NVIDIA Corporation\Nsight Systems 2024.5.1\target-windows-x64\nsys.exe'
    $text=$text.Replace('"%SERVER_EXE%" ^',('"'+$nsys+'" launch --session-new=qwen_'+$Label+' --trace=cuda --cuda-graph-trace=node "%SERVER_EXE%" ^'))
}
$launch=Join-Path $runDir 'launch.cmd'
[System.IO.File]::WriteAllText($launch,$text,[System.Text.Encoding]::ASCII)
$binaryDir='C:/Users/imanu/Documents/Codex/2026-09-09/c-users-imanu-source-repos-moe/work/qwen38_clean/build/bin'
$hashes=@{}
foreach($name in @('ggml-cuda.dll','ggml-base.dll','llama.dll','llama-common.dll')) {
    $hashes[$name]=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $binaryDir $name)).Hash.ToLowerInvariant()
}
$hashes | ConvertTo-Json | Set-Content (Join-Path $runDir 'binary_hashes.json')
$env:QWEN4EXP_SPARSE_FA=[string]$Sfa
$env:MOE_SLOTS=[string]$Slots
$env:DRAFT_EXPERTS='ram'
$env:SPEC_TYPES=$Specs
$env:SPEC_N_MAX='1'
$env:SPEC_N_MIN='1'
$env:SPEC_P_MIN='0'
$env:LLAMA_SPEC_PROFILE='1'
$env:QWEN_GDN_TILED=[string]$GdnTiled
$env:QWEN_PREFETCH_EXPERTS=[string]$Prefetch
$env:QWEN_NGRAM_ROLLBACK=[string]$NgramRollback
Remove-Item Env:\LLAMA_MOE_HIT_REPORT,Env:\LLAMA_MOE_ROUTE_TRACE,Env:\GGML_CUDA_DISABLE_GRAPHS -ErrorAction SilentlyContinue
$p=Start-Process -FilePath cmd.exe -ArgumentList '/c',('"'+$launch+'" '+$Mtp) -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runDir 'launcher.out') -RedirectStandardError (Join-Path $runDir 'launcher.err') -PassThru
@{label=$Label;batch=$Batch;mtp=$Mtp;slots=$Slots;sfa=$Sfa;specs=$Specs;ngram_m=$NgramM;gdn_tiled=$GdnTiled;prefetch=$Prefetch;ngram_rollback=$NgramRollback;nsight=[bool]$Nsight;launcher_pid=$p.Id} | ConvertTo-Json | Set-Content (Join-Path $runDir 'config.json')
Write-Output "Avviato $Label (batch=$Batch, mtp=$Mtp, specs=$Specs), lanciatore PID=$($p.Id)"
