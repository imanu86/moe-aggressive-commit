#include "ngram-map.h"

#include <iostream>

static int failures = 0;
#ifndef EXPECT_SIMPLE_SHORT
#define EXPECT_SIMPLE_SHORT 0
#endif

static void run_case(uint16_t n, uint16_t m, const llama_tokens & history, llama_token sampled) {
    common_ngram_map map(n, m, true, 1);
    // begin() marks the pre-existing prefix; draft() learns from newly appended output.
    const llama_tokens empty;
    common_ngram_map_begin(map, empty);
    llama_tokens draft;
    common_ngram_map_draft(map, history, sampled, draft);
    std::cout << "map n=" << n << " m=" << m << " history=" << history.size()
              << " sampled=" << sampled << " draft=";
    for (llama_token t : draft) std::cout << " " << t;
    std::cout << "\n";
    if (draft != llama_tokens{3,4}) ++failures;
}

static void run_simple_case(uint16_t n, uint16_t m, const llama_tokens & history, llama_token sampled) {
    common_ngram_simple_config config{ n, m };
    const llama_tokens draft = common_ngram_simple_draft(config, history, sampled);
    std::cout << "simple n=" << n << " m=" << m << " history=" << history.size()
              << " sampled=" << sampled << " draft=";
    for (llama_token t : draft) std::cout << " " << t;
    std::cout << "\n";
    const llama_tokens expected = (n <= m || EXPECT_SIMPLE_SHORT) ? llama_tokens{3,4} : llama_tokens{};
    if (draft != expected) ++failures;
}

int main() {
    // Repeated pairs: completing the final [1,2] should copy the earlier [3,4].
    llama_tokens repeated;
    for (int i = 0; i < 8; ++i) {
        repeated.push_back(1);
        repeated.push_back(2);
        repeated.push_back(3);
        repeated.push_back(4);
    }
    repeated.push_back(1); // sampled=2 completes the final [1,2] key.
    run_case(12, 2, repeated, 2);
    run_case(2, 2, repeated, 2);
    run_simple_case(12, 2, repeated, 2);
    run_simple_case(2, 2, repeated, 2);
    std::cout << "failures=" << failures << "\n";
    return failures ? 1 : 0;
}
