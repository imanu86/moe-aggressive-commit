@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "ROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean"
cl /nologo /std:c++17 /O2 /EHsc /MD /DGGML_SHARED /DGGML_BACKEND_SHARED /I"%ROOT%\source\ggml\include" "%~dp0scheduler_probe.cpp" /link "%ROOT%\build\ggml\src\ggml-base.lib" "%ROOT%\build\ggml\src\ggml.lib" "%ROOT%\build\ggml\src\ggml-cpu.lib" "%ROOT%\build\ggml\src\ggml-cuda\ggml-cuda.lib" /OUT:"%~dp0scheduler_probe.exe"
exit /b %ERRORLEVEL%

