#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-alloc.h"
#include "ggml-cpu.h"
#include "ggml-cuda.h"
#include <cstdio>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <algorithm>

int main() {
    constexpr int K=256, R=16, E=512, T=512, A=2, N=3;
    auto * cw=ggml_init({4ull<<20,nullptr,true});
    auto * ci=ggml_init({4ull<<20,nullptr,true});
    auto * cg=ggml_init({4ull<<20,nullptr,true});
    auto cpu=ggml_backend_cpu_init();
    auto gpu=ggml_backend_cuda_init(0);
    if (!cw || !ci || !cg || !cpu || !gpu) return 1;
    ggml_tensor * w[N];
    for(int j=0;j<N;++j) { w[j]=ggml_new_tensor_3d(cw,GGML_TYPE_Q4_0,K,R,E); ggml_format_name(w[j],"weights_%d",j); }
    auto * x=ggml_new_tensor_3d(ci,GGML_TYPE_F32,K,1,T);
    auto * ids=ggml_new_tensor_2d(ci,GGML_TYPE_I32,A,T);
    ggml_set_name(x,"input"); ggml_set_name(ids,"ids"); ggml_set_input(x); ggml_set_input(ids);
    auto bw=ggml_backend_alloc_ctx_tensors_from_buft(cw,ggml_backend_cuda_host_buffer_type());
    auto bi=ggml_backend_alloc_ctx_tensors_from_buft(ci,ggml_backend_cpu_buffer_type());
    if (!bw || !bi) return 2;
    ggml_backend_buffer_set_usage(bw,GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
    std::vector<float> src(K*R*E), xin(K*T,1.f);
    std::vector<int32_t> ii(A*T);
    std::vector<float> dequant[N];
    for(int t=0;t<T;++t) for(int a=0;a<A;++a) ii[t*A+a]=(t*7+a*137)%E;
    ggml_quantize_init(GGML_TYPE_Q4_0);
    for(int j=0;j<N;++j) {
        for(int e=0;e<E;++e) for(int r=0;r<R;++r) for(int k=0;k<K;++k)
            src[(e*R+r)*K+k]=j*.25f+(e%17-8)*.0625f+(r+1)*.03125f+(k%16-8)*.015625f;
        size_t written=ggml_quantize_chunk(GGML_TYPE_Q4_0,src.data(),w[j]->data,0,R*E,K,nullptr);
        if(written!=ggml_nbytes(w[j])) return 3;
        dequant[j].resize(src.size());
        ggml_get_type_traits(GGML_TYPE_Q4_0)->to_float(w[j]->data,dequant[j].data(),src.size());
    }
    ggml_quantize_free();
    ggml_backend_tensor_set(x,xin.data(),0,ggml_nbytes(x));
    ggml_backend_tensor_set(ids,ii.data(),0,ggml_nbytes(ids));
    auto * graph=ggml_new_graph_custom(cg,256,false);
    ggml_tensor * out[N];
    for(int j=0;j<N;++j) { out[j]=ggml_mul_mat_id(cg,w[j],x,ids); ggml_set_output(out[j]); ggml_build_forward_expand(graph,out[j]); }
    ggml_backend_t backends[]={gpu,cpu};
    ggml_backend_buffer_type_t bufts[]={ggml_backend_get_default_buffer_type(gpu),ggml_backend_cpu_buffer_type()};
    auto sched=ggml_backend_sched_new(backends,bufts,2,256,false,true);
    for(int j=0;j<N;++j) ggml_backend_sched_set_tensor_backend(sched,out[j],gpu);
    if(!ggml_backend_sched_alloc_graph(sched,graph)) return 4;
    int failures=0;
    for(int repeat=0;repeat<3;++repeat) {
        if(ggml_backend_sched_graph_compute(sched,graph)!=GGML_STATUS_SUCCESS) return 5;
        for(int j=0;j<N;++j) {
            std::vector<float> got(ggml_nelements(out[j]));
            ggml_backend_tensor_get(out[j],got.data(),0,ggml_nbytes(out[j]));
            double maxabs=0; uint64_t hash=1469598103934665603ull;
            for(int t=0;t<T;++t) for(int a=0;a<A;++a) for(int r=0;r<R;++r) {
                double expected=0;
                const float * row=&dequant[j][(ii[t*A+a]*R+r)*K];
                for(int k=0;k<K;++k) expected+=row[k];
                float actual=got[(t*A+a)*R+r];
                double diff=std::abs(actual-expected);
                maxabs=std::max(maxabs,diff);
                if(!std::isfinite(actual) || diff>.003+.0003*std::abs(expected)) ++failures;
            }
            for(auto p=(unsigned char*)got.data();p<(unsigned char*)(got.data()+got.size());++p) hash=(hash^*p)*1099511628211ull;
            std::printf("repeat=%d op=%d maxabs=%.9g fnv64=%016llx\n",repeat,j,maxabs,(unsigned long long)hash);
        }
    }
    ggml_backend_sched_free(sched); ggml_backend_buffer_free(bi); ggml_backend_buffer_free(bw);
    ggml_backend_free(gpu); ggml_backend_free(cpu); ggml_free(cg); ggml_free(ci); ggml_free(cw);
    std::printf("failures=%d\n",failures);
    return failures ? 6 : 0;
}
