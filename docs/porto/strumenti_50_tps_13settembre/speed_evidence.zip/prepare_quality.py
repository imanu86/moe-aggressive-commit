from pathlib import Path
here=Path(__file__).resolve().parent
source=Path(r'C:/Users/imanu/source/repos/moe-aggressive-commit/docs/porto/strumenti_qwen38_13settembre/prova_reale.py').read_text()
source=source.replace("bat = pathlib.Path(r'C:\\Users\\imanu\\Desktop\\avvia Qwen38 250k DeepSeek Harness.bat').read_text(errors='replace')", "bat = (HERE/'launch.cmd').read_text(errors='replace')")
source=source.replace("'stream_options': {'include_usage': True}, 'temperature': 0}","'stream_options': {'include_usage': True}, 'temperature': 0, 'seed':1234, 'cache_prompt':bool(esiti)}")
source=source.replace("'n_gen': n_gen,", "'n_gen': n_gen,\n        'timings': timings,")
source=source.replace("atteso.lower() in (r['testo'] + r['ragionamento']).lower()", "atteso.lower() in r['testo'].lower()")
run=here/'mtp_ngram2_prefetch_rs'
(run/'prova_reale.py').write_text(source,encoding='utf-8')
print('Prepared quality test: first prompt cache disabled, timings retained, matches require final content.')
