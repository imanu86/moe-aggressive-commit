@echo off
setlocal
set "ROOT=C:\Users\imanu\Documents\Codex\2026-09-09\c-users-imanu-source-repos-moe\work\qwen38_clean"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /O2 /EHsc /MD /DGGML_SHARED /I"%ROOT%\source\common" /I"%ROOT%\source\include" /I"%ROOT%\source\ggml\include" "%~dp0rollback_probe.cpp" /link "%ROOT%\build\common\llama-common.lib" "%ROOT%\build\common\llama-common-base.lib" "%ROOT%\build\src\llama.lib" /OUT:"%~dp0rollback_probe.exe"
exit /b %ERRORLEVEL%
