#include "common.h"
#include <cstdio>
#include <cstdlib>

int main() {
    int failures = 0;
    auto test = [&](const char * label, bool enabled, std::vector<common_speculative_type> types,
                    int draft_max, int ngram_max, uint32_t expected) {
        _putenv_s("QWEN_NGRAM_ROLLBACK", enabled ? "1" : "0");
        common_params params;
        params.speculative.types = types;
        params.speculative.draft.n_max = draft_max;
        params.speculative.ngram_simple.size_m = ngram_max;
        auto result = common_context_params_to_llama(params);
        bool ok = result.n_rs_seq == expected;
        std::printf("%s: n_rs_seq=%u expected=%u %s\n", label, result.n_rs_seq, expected, ok ? "PASS" : "FAIL");
        failures += !ok;
    };
    test("off_mtp1_ngram2", false, {COMMON_SPECULATIVE_TYPE_DRAFT_MTP,COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 1, 2, 1);
    test("on_mtp1_ngram2", true, {COMMON_SPECULATIVE_TYPE_DRAFT_MTP,COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 1, 2, 2);
    test("on_ngram2_only", true, {COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 1, 2, 2);
    test("on_mtp3_preserved", true, {COMMON_SPECULATIVE_TYPE_DRAFT_MTP,COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 3, 2, 3);
    test("on_large_ngram_unchanged", true, {COMMON_SPECULATIVE_TYPE_DRAFT_MTP,COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 1, 48, 1);
    test("on_none_unchanged", true, {COMMON_SPECULATIVE_TYPE_NONE}, 1, 2, 0);
    test("on_mtp_without_ngram", true, {COMMON_SPECULATIVE_TYPE_DRAFT_MTP}, 1, 2, 1);
    test("on_ngram1_only", true, {COMMON_SPECULATIVE_TYPE_NGRAM_SIMPLE}, 1, 1, 1);
    std::printf("failures=%d\n",failures);
    return failures ? 1 : 0;
}
