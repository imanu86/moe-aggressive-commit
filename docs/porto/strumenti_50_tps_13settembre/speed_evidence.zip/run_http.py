import argparse
import json
import pathlib
import re
import subprocess
import sys
import time
import urllib.request

ap=argparse.ArgumentParser()
ap.add_argument('--label',required=True)
ap.add_argument('--ctx',type=int,default=32000)
ap.add_argument('--tokens',type=int,default=128)
ap.add_argument('--repeat',type=int,default=1)
ap.add_argument('--fresh',action='store_true')
args=ap.parse_args()
here=pathlib.Path(__file__).resolve().parent
run=here/args.label
launcher=(run/'launch.cmd').read_text()
key=re.search(r'set "API_KEY=([^"]*)"',launcher).group(1)
for attempt in range(108):
    try:
        req=urllib.request.Request('http://127.0.0.1:8110/health',headers={'Authorization':'Bearer '+key})
        with urllib.request.urlopen(req,timeout=4) as response:
            if response.status==200:break
    except OSError:
        time.sleep(5)
else:raise RuntimeError('Server non pronto')
print('Server pronto: '+args.label,flush=True)
script=pathlib.Path(r'C:\Users\imanu\source\repos\moe-aggressive-commit\docs\porto\strumenti_qwen38_13settembre\banco_http.py')
if args.fresh:
    source=script.read_text(encoding='utf-8')
    needle="'timings_per_token': False"
    assert source.count(needle)==1
    script=here/'banco_fresh.py'
    script.write_text(source.replace(needle,needle+", 'cache_prompt': False"),encoding='utf-8')
for rep in range(args.repeat):
    subprocess.run([sys.executable,str(script),'--url','http://127.0.0.1:8110','--ctx-tokens',str(args.ctx),
                    '--max-tokens',str(args.tokens),'--turns','1','--temperature','0','--label',args.label+f'_r{rep+1}',
                    '--out',str(run/'bench.jsonl')],check=True)
